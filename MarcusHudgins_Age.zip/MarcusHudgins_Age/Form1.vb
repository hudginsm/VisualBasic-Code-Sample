﻿Public Class Form1
    Private Sub btn_ShowMessage_Click(sender As Object, e As EventArgs) Handles btn_ShowMessage.Click
        Dim age As Integer
        age = txtAge.Text

        If age <= 1 Then
            lblAgeRange.Text = "Infant"
        ElseIf age >= 2 And age <= 4 Then
            lblAgeRange.Text = "Toddler"
        ElseIf age >= 5 And age <= 10 Then
            lblAgeRange.Text = "Kid"
        ElseIf age >= 11 And age <= 12 Then
            lblAgeRange.Text = "Preteen"
        ElseIf age >= 13 And age <= 19 Then
            lblAgeRange.Text = "Teenager"
        ElseIf age >= 20 And age <= 30 Then
            lblAgeRange.Text = "Young Adult"
        Else
            lblAgeRange.Text = "Adult"
        End If
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        txtAge.Clear()
        lblAgeRange.Text = String.Empty
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub
End Class
