﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblAgeRange = New System.Windows.Forms.Label()
        Me.txtAge = New System.Windows.Forms.TextBox()
        Me.btn_ShowMessage = New System.Windows.Forms.Button()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Stencil", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(53, 36)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(286, 32)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Find you age range"
        '
        'lblAgeRange
        '
        Me.lblAgeRange.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblAgeRange.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAgeRange.Font = New System.Drawing.Font("Showcard Gothic", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAgeRange.Location = New System.Drawing.Point(59, 169)
        Me.lblAgeRange.Name = "lblAgeRange"
        Me.lblAgeRange.Size = New System.Drawing.Size(280, 62)
        Me.lblAgeRange.TabIndex = 1
        Me.lblAgeRange.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtAge
        '
        Me.txtAge.Font = New System.Drawing.Font("Modern No. 20", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAge.Location = New System.Drawing.Point(150, 93)
        Me.txtAge.Name = "txtAge"
        Me.txtAge.Size = New System.Drawing.Size(98, 45)
        Me.txtAge.TabIndex = 2
        Me.txtAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_ShowMessage
        '
        Me.btn_ShowMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ShowMessage.Location = New System.Drawing.Point(12, 261)
        Me.btn_ShowMessage.Name = "btn_ShowMessage"
        Me.btn_ShowMessage.Size = New System.Drawing.Size(107, 52)
        Me.btn_ShowMessage.TabIndex = 3
        Me.btn_ShowMessage.Text = "Show Message"
        Me.btn_ShowMessage.UseVisualStyleBackColor = True
        '
        'btn_Clear
        '
        Me.btn_Clear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Clear.Location = New System.Drawing.Point(150, 261)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(98, 52)
        Me.btn_Clear.TabIndex = 4
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Exit.Location = New System.Drawing.Point(280, 261)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(98, 52)
        Me.btn_Exit.TabIndex = 5
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(390, 325)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.btn_Clear)
        Me.Controls.Add(Me.btn_ShowMessage)
        Me.Controls.Add(Me.txtAge)
        Me.Controls.Add(Me.lblAgeRange)
        Me.Controls.Add(Me.lblTitle)
        Me.Name = "Form1"
        Me.Text = "Age"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents lblAgeRange As Label
    Friend WithEvents txtAge As TextBox
    Friend WithEvents btn_ShowMessage As Button
    Friend WithEvents btn_Clear As Button
    Friend WithEvents btn_Exit As Button
End Class
