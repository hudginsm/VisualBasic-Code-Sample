﻿Public Class Form1
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Dim strDisplay As String
        'If lstMonths.SelectedIndex = -1 Then
        'MessageBox.Show("Select a Month")
        ' ElseIf lstYears.SelectedIndex = -1 Then
        'MessageBox.Show("Select a Year")
        'Else
        ' strDisplay = lstMonths.SelectedItem.ToString() & " " & lstYears.SelectedItem.ToString()
        ' MessageBox.Show("You selected: " & strDisplay)
        'End If

        If clbYears.SelectedItem = True Then
            MessageBox.Show(clbYears.SelectedItem)
        End If

        If cboMonths.Text = "Jan" Then
            MessageBox.Show(cboMonths.Text)
        ElseIf cboMonths.Text = "Feb" Then
            MessageBox.Show(cboMonths.Text)
        End If


    End Sub

    Private Sub btnRESET_Click(sender As Object, e As EventArgs) Handles btnRESET.Click
        lstMonths.SelectedIndex = -1
        lstYears.SelectedIndex = -1
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        lstYears.Items.Add(txtNewYear.Text)

    End Sub
End Class
