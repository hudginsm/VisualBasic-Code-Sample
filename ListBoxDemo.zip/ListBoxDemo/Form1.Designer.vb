﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstMonths = New System.Windows.Forms.ListBox()
        Me.lstYears = New System.Windows.Forms.ListBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnRESET = New System.Windows.Forms.Button()
        Me.txtNewYear = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.clbYears = New System.Windows.Forms.CheckedListBox()
        Me.cboMonths = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'lstMonths
        '
        Me.lstMonths.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstMonths.FormattingEnabled = True
        Me.lstMonths.ItemHeight = 34
        Me.lstMonths.Items.AddRange(New Object() {"Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"})
        Me.lstMonths.Location = New System.Drawing.Point(61, 27)
        Me.lstMonths.Name = "lstMonths"
        Me.lstMonths.Size = New System.Drawing.Size(134, 208)
        Me.lstMonths.TabIndex = 0
        '
        'lstYears
        '
        Me.lstYears.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstYears.FormattingEnabled = True
        Me.lstYears.ItemHeight = 34
        Me.lstYears.Items.AddRange(New Object() {"2015", "2016", "2017", "2018", "2019", "2020"})
        Me.lstYears.Location = New System.Drawing.Point(241, 27)
        Me.lstYears.Name = "lstYears"
        Me.lstYears.Size = New System.Drawing.Size(100, 208)
        Me.lstYears.TabIndex = 1
        '
        'btnOK
        '
        Me.btnOK.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.Location = New System.Drawing.Point(44, 281)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(151, 51)
        Me.btnOK.TabIndex = 2
        Me.btnOK.Text = "Ok"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnRESET
        '
        Me.btnRESET.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRESET.Location = New System.Drawing.Point(241, 281)
        Me.btnRESET.Name = "btnRESET"
        Me.btnRESET.Size = New System.Drawing.Size(151, 51)
        Me.btnRESET.TabIndex = 3
        Me.btnRESET.Text = "Reset"
        Me.btnRESET.UseVisualStyleBackColor = True
        '
        'txtNewYear
        '
        Me.txtNewYear.Location = New System.Drawing.Point(165, 255)
        Me.txtNewYear.Name = "txtNewYear"
        Me.txtNewYear.Size = New System.Drawing.Size(100, 20)
        Me.txtNewYear.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(58, 258)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Enter A Year"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(306, 255)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 6
        Me.btnAdd.Text = "Add to List"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'clbYears
        '
        Me.clbYears.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.clbYears.FormattingEnabled = True
        Me.clbYears.Items.AddRange(New Object() {"2016", "2017", "2018", "2019", "2020"})
        Me.clbYears.Location = New System.Drawing.Point(388, 46)
        Me.clbYears.Name = "clbYears"
        Me.clbYears.Size = New System.Drawing.Size(120, 189)
        Me.clbYears.TabIndex = 7
        '
        'cboMonths
        '
        Me.cboMonths.FormattingEnabled = True
        Me.cboMonths.Items.AddRange(New Object() {"Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"})
        Me.cboMonths.Location = New System.Drawing.Point(559, 116)
        Me.cboMonths.Name = "cboMonths"
        Me.cboMonths.Size = New System.Drawing.Size(121, 21)
        Me.cboMonths.TabIndex = 8
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(745, 373)
        Me.Controls.Add(Me.cboMonths)
        Me.Controls.Add(Me.clbYears)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtNewYear)
        Me.Controls.Add(Me.btnRESET)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.lstYears)
        Me.Controls.Add(Me.lstMonths)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstMonths As ListBox
    Friend WithEvents lstYears As ListBox
    Friend WithEvents btnOK As Button
    Friend WithEvents btnRESET As Button
    Friend WithEvents txtNewYear As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents clbYears As CheckedListBox
    Friend WithEvents cboMonths As ComboBox
End Class
