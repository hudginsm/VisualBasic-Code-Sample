﻿Public Class Form1
    Private Sub btn_Continue_Click(sender As Object, e As EventArgs) Handles btn_Continue.Click
        'Declare variables to hold the radian button input
        Dim English, German, Chinese As Boolean
        'Initualize the variables to the corrosponding radian buttons
        English = rad_English.Checked
        German = rad_German.Checked
        Chinese = rad_Chinese.Checked
        'Find out which language was selected
        If English = True Then
            lbl_Language.Text = "English"
        ElseIf German = True Then
            lbl_Language.Text = "German"
        ElseIf Chinese = True Then
            lbl_Language.Text = "Chinese"
        End If
        'Declare variables to hold the check box input and price total
        Dim Meso, AnEurope, MedEurope, EastAsia As Boolean
        Dim totalPrice As Double = 0
        'Intualize the variables to the corrosponding check boxes
        Meso = chk_Mesopotamia.Checked
        AnEurope = chk_AnEurope.Checked
        MedEurope = chk_MedEurope.Checked
        EastAsia = chk_EastAsia.Checked
        'Find out which sctions are selected and total up the price
        If Meso = True Then
            lbl_Sections.Text &= "Ancient Mesopotamia"
            totalPrice = totalPrice + 25
            lbl_Price.Text = totalPrice.ToString("c")
        End If
        If AnEurope = True Then
            lbl_Sections.Text &= " Ancient Europe"
            totalPrice = totalPrice + 25
            lbl_Price.Text = totalPrice.ToString("c")
        End If
        If MedEurope = True Then
            lbl_Sections.Text &= " Medieval Europe"
            totalPrice = totalPrice + 30
            lbl_Price.Text = totalPrice.ToString("c")
        End If
        If EastAsia = True Then
            lbl_Sections.Text &= " East Asia"
            totalPrice = totalPrice + 35
            lbl_Price.Text = totalPrice.ToString("c")
        End If
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        'Clears the labels holding data about the tour
        lbl_Price.Text = String.Empty
        lbl_Language.Text = String.Empty
        lbl_Sections.Text = String.Empty
        'Clears checks boxes
        chk_Mesopotamia.Checked = False
        chk_AnEurope.Checked = False
        chk_MedEurope.Checked = False
        chk_EastAsia.Checked = False
        'Clears radian buttons
        rad_English.Checked = False
        rad_German.Checked = False
        rad_Chinese.Checked = False

    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        'Closes the application
        Me.Close()
    End Sub
End Class
