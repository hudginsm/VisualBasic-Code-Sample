﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rad_Chinese = New System.Windows.Forms.RadioButton()
        Me.rad_German = New System.Windows.Forms.RadioButton()
        Me.rad_English = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chk_EastAsia = New System.Windows.Forms.CheckBox()
        Me.chk_MedEurope = New System.Windows.Forms.CheckBox()
        Me.chk_AnEurope = New System.Windows.Forms.CheckBox()
        Me.chk_Mesopotamia = New System.Windows.Forms.CheckBox()
        Me.btn_Continue = New System.Windows.Forms.Button()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lbl_Sections = New System.Windows.Forms.Label()
        Me.lbl_Language = New System.Windows.Forms.Label()
        Me.lbl_Price = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rad_Chinese)
        Me.GroupBox1.Controls.Add(Me.rad_German)
        Me.GroupBox1.Controls.Add(Me.rad_English)
        Me.GroupBox1.Location = New System.Drawing.Point(54, 134)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(81, 226)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Languages"
        '
        'rad_Chinese
        '
        Me.rad_Chinese.AutoSize = True
        Me.rad_Chinese.Location = New System.Drawing.Point(6, 145)
        Me.rad_Chinese.Name = "rad_Chinese"
        Me.rad_Chinese.Size = New System.Drawing.Size(63, 17)
        Me.rad_Chinese.TabIndex = 2
        Me.rad_Chinese.TabStop = True
        Me.rad_Chinese.Text = "Chinese"
        Me.rad_Chinese.UseVisualStyleBackColor = True
        '
        'rad_German
        '
        Me.rad_German.AutoSize = True
        Me.rad_German.Location = New System.Drawing.Point(6, 103)
        Me.rad_German.Name = "rad_German"
        Me.rad_German.Size = New System.Drawing.Size(62, 17)
        Me.rad_German.TabIndex = 1
        Me.rad_German.TabStop = True
        Me.rad_German.Text = "German"
        Me.rad_German.UseVisualStyleBackColor = True
        '
        'rad_English
        '
        Me.rad_English.AutoSize = True
        Me.rad_English.Location = New System.Drawing.Point(6, 62)
        Me.rad_English.Name = "rad_English"
        Me.rad_English.Size = New System.Drawing.Size(59, 17)
        Me.rad_English.TabIndex = 0
        Me.rad_English.TabStop = True
        Me.rad_English.Text = "English"
        Me.rad_English.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chk_EastAsia)
        Me.GroupBox2.Controls.Add(Me.chk_MedEurope)
        Me.GroupBox2.Controls.Add(Me.chk_AnEurope)
        Me.GroupBox2.Controls.Add(Me.chk_Mesopotamia)
        Me.GroupBox2.Location = New System.Drawing.Point(169, 134)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(222, 226)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Sections to be Toured"
        '
        'chk_EastAsia
        '
        Me.chk_EastAsia.AutoSize = True
        Me.chk_EastAsia.Location = New System.Drawing.Point(19, 189)
        Me.chk_EastAsia.Name = "chk_EastAsia"
        Me.chk_EastAsia.Size = New System.Drawing.Size(97, 17)
        Me.chk_EastAsia.TabIndex = 3
        Me.chk_EastAsia.Text = "East Asia ($35)"
        Me.chk_EastAsia.UseVisualStyleBackColor = True
        '
        'chk_MedEurope
        '
        Me.chk_MedEurope.AutoSize = True
        Me.chk_MedEurope.Location = New System.Drawing.Point(19, 145)
        Me.chk_MedEurope.Name = "chk_MedEurope"
        Me.chk_MedEurope.Size = New System.Drawing.Size(133, 17)
        Me.chk_MedEurope.TabIndex = 2
        Me.chk_MedEurope.Text = "Medieval Europe ($30)"
        Me.chk_MedEurope.UseVisualStyleBackColor = True
        '
        'chk_AnEurope
        '
        Me.chk_AnEurope.AutoSize = True
        Me.chk_AnEurope.Location = New System.Drawing.Point(19, 102)
        Me.chk_AnEurope.Name = "chk_AnEurope"
        Me.chk_AnEurope.Size = New System.Drawing.Size(126, 17)
        Me.chk_AnEurope.TabIndex = 1
        Me.chk_AnEurope.Text = "Ancient Europe ($25)"
        Me.chk_AnEurope.UseVisualStyleBackColor = True
        '
        'chk_Mesopotamia
        '
        Me.chk_Mesopotamia.AutoSize = True
        Me.chk_Mesopotamia.Location = New System.Drawing.Point(19, 60)
        Me.chk_Mesopotamia.Name = "chk_Mesopotamia"
        Me.chk_Mesopotamia.Size = New System.Drawing.Size(155, 17)
        Me.chk_Mesopotamia.TabIndex = 0
        Me.chk_Mesopotamia.Text = "Ancient Mesopotamia ($25)"
        Me.chk_Mesopotamia.UseVisualStyleBackColor = True
        '
        'btn_Continue
        '
        Me.btn_Continue.Location = New System.Drawing.Point(443, 460)
        Me.btn_Continue.Name = "btn_Continue"
        Me.btn_Continue.Size = New System.Drawing.Size(75, 23)
        Me.btn_Continue.TabIndex = 3
        Me.btn_Continue.Text = "Continue"
        Me.btn_Continue.UseVisualStyleBackColor = True
        '
        'btn_Clear
        '
        Me.btn_Clear.Location = New System.Drawing.Point(546, 460)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(75, 23)
        Me.btn_Clear.TabIndex = 4
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Location = New System.Drawing.Point(648, 460)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(75, 23)
        Me.btn_Exit.TabIndex = 5
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lbl_Sections)
        Me.GroupBox3.Controls.Add(Me.lbl_Language)
        Me.GroupBox3.Controls.Add(Me.lbl_Price)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Location = New System.Drawing.Point(765, 134)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(196, 226)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "GroupBox3"
        '
        'lbl_Sections
        '
        Me.lbl_Sections.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Sections.Location = New System.Drawing.Point(75, 122)
        Me.lbl_Sections.Name = "lbl_Sections"
        Me.lbl_Sections.Size = New System.Drawing.Size(100, 84)
        Me.lbl_Sections.TabIndex = 5
        '
        'lbl_Language
        '
        Me.lbl_Language.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Language.Location = New System.Drawing.Point(75, 79)
        Me.lbl_Language.Name = "lbl_Language"
        Me.lbl_Language.Size = New System.Drawing.Size(100, 23)
        Me.lbl_Language.TabIndex = 4
        '
        'lbl_Price
        '
        Me.lbl_Price.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Price.Location = New System.Drawing.Point(75, 39)
        Me.lbl_Price.Name = "lbl_Price"
        Me.lbl_Price.Size = New System.Drawing.Size(100, 23)
        Me.lbl_Price.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 145)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Sections:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 89)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Language:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(35, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Price:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1156, 526)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.btn_Clear)
        Me.Controls.Add(Me.btn_Continue)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rad_Chinese As RadioButton
    Friend WithEvents rad_German As RadioButton
    Friend WithEvents rad_English As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chk_EastAsia As CheckBox
    Friend WithEvents chk_MedEurope As CheckBox
    Friend WithEvents chk_AnEurope As CheckBox
    Friend WithEvents chk_Mesopotamia As CheckBox
    Friend WithEvents btn_Continue As Button
    Friend WithEvents btn_Clear As Button
    Friend WithEvents btn_Exit As Button
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents lbl_Sections As Label
    Friend WithEvents lbl_Language As Label
    Friend WithEvents lbl_Price As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
