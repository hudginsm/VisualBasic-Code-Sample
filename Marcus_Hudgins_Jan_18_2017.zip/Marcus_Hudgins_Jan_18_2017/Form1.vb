﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_First_Click(sender As Object, e As EventArgs) Handles btn_First.Click
        lbl_ClickBtn.Text = "You clicked the first button."
    End Sub

    Private Sub btn_Second_Click(sender As Object, e As EventArgs) Handles btn_Second.Click
        lbl_ClickBtn.Text = "You clicked the second button."
    End Sub

    Private Sub btn_Third_Click(sender As Object, e As EventArgs) Handles btn_Third.Click
        lbl_ClickBtn.Text = "You clicked the third button."
    End Sub
End Class
