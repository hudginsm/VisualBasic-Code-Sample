﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_First = New System.Windows.Forms.Button()
        Me.lbl_ClickBtn = New System.Windows.Forms.Label()
        Me.btn_Second = New System.Windows.Forms.Button()
        Me.btn_Third = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_First
        '
        Me.btn_First.AutoSize = True
        Me.btn_First.Location = New System.Drawing.Point(501, 370)
        Me.btn_First.Name = "btn_First"
        Me.btn_First.Size = New System.Drawing.Size(109, 54)
        Me.btn_First.TabIndex = 0
        Me.btn_First.Text = "First"
        Me.btn_First.UseVisualStyleBackColor = True
        '
        'lbl_ClickBtn
        '
        Me.lbl_ClickBtn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_ClickBtn.Cursor = System.Windows.Forms.Cursors.Default
        Me.lbl_ClickBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ClickBtn.Location = New System.Drawing.Point(481, 170)
        Me.lbl_ClickBtn.Name = "lbl_ClickBtn"
        Me.lbl_ClickBtn.Size = New System.Drawing.Size(285, 133)
        Me.lbl_ClickBtn.TabIndex = 1
        Me.lbl_ClickBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_Second
        '
        Me.btn_Second.Location = New System.Drawing.Point(657, 370)
        Me.btn_Second.Name = "btn_Second"
        Me.btn_Second.Size = New System.Drawing.Size(109, 54)
        Me.btn_Second.TabIndex = 2
        Me.btn_Second.Text = "Second"
        Me.btn_Second.UseVisualStyleBackColor = True
        '
        'btn_Third
        '
        Me.btn_Third.Location = New System.Drawing.Point(829, 370)
        Me.btn_Third.Name = "btn_Third"
        Me.btn_Third.Size = New System.Drawing.Size(109, 54)
        Me.btn_Third.TabIndex = 3
        Me.btn_Third.Text = "Third"
        Me.btn_Third.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1301, 536)
        Me.Controls.Add(Me.btn_Third)
        Me.Controls.Add(Me.btn_Second)
        Me.Controls.Add(Me.lbl_ClickBtn)
        Me.Controls.Add(Me.btn_First)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_First As Button
    Friend WithEvents lbl_ClickBtn As Label
    Friend WithEvents btn_Second As Button
    Friend WithEvents btn_Third As Button
End Class
