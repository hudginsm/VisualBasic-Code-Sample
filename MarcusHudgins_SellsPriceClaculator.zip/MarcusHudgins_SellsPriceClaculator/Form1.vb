﻿Public Class Form1
    Private Sub btn_Calculate_Click(sender As Object, e As EventArgs) Handles btn_Calculate.Click
        Dim OrgPrice, DiscountPre, DiscountPrice, SalePrice As Double

        OrgPrice = txt_OrgPrice.Text
        DiscountPre = txt_Discount.Text
        DiscountPre = DiscountPre / 100
        DiscountPrice = OrgPrice * DiscountPre
        SalePrice = OrgPrice - DiscountPrice

        lbl_NewPrice.Text = SalePrice.ToString("c")
        '.ToString("c") is use to convert your answer to money.
    End Sub

    Private Sub btn_Close_Click(sender As Object, e As EventArgs) Handles btn_Close.Click
        Me.Close()
    End Sub
End Class
