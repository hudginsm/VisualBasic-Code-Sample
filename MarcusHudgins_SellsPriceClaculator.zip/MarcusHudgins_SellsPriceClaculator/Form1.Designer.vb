﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_OrgPrice = New System.Windows.Forms.Label()
        Me.lbl_Discount = New System.Windows.Forms.Label()
        Me.lbl_Sale = New System.Windows.Forms.Label()
        Me.lbl_NewPrice = New System.Windows.Forms.Label()
        Me.btn_Calculate = New System.Windows.Forms.Button()
        Me.btn_Close = New System.Windows.Forms.Button()
        Me.txt_OrgPrice = New System.Windows.Forms.TextBox()
        Me.txt_Discount = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lbl_OrgPrice
        '
        Me.lbl_OrgPrice.AutoSize = True
        Me.lbl_OrgPrice.Location = New System.Drawing.Point(39, 15)
        Me.lbl_OrgPrice.Name = "lbl_OrgPrice"
        Me.lbl_OrgPrice.Size = New System.Drawing.Size(115, 13)
        Me.lbl_OrgPrice.TabIndex = 0
        Me.lbl_OrgPrice.Text = "Enter the Original Price"
        '
        'lbl_Discount
        '
        Me.lbl_Discount.AutoSize = True
        Me.lbl_Discount.Location = New System.Drawing.Point(1, 45)
        Me.lbl_Discount.Name = "lbl_Discount"
        Me.lbl_Discount.Size = New System.Drawing.Size(153, 13)
        Me.lbl_Discount.TabIndex = 1
        Me.lbl_Discount.Text = "Enter the Discount Percentage"
        '
        'lbl_Sale
        '
        Me.lbl_Sale.AutoSize = True
        Me.lbl_Sale.Location = New System.Drawing.Point(99, 85)
        Me.lbl_Sale.Name = "lbl_Sale"
        Me.lbl_Sale.Size = New System.Drawing.Size(55, 13)
        Me.lbl_Sale.TabIndex = 2
        Me.lbl_Sale.Text = "Sale Price"
        '
        'lbl_NewPrice
        '
        Me.lbl_NewPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_NewPrice.Cursor = System.Windows.Forms.Cursors.Default
        Me.lbl_NewPrice.Location = New System.Drawing.Point(162, 84)
        Me.lbl_NewPrice.Name = "lbl_NewPrice"
        Me.lbl_NewPrice.Size = New System.Drawing.Size(100, 24)
        Me.lbl_NewPrice.TabIndex = 3
        '
        'btn_Calculate
        '
        Me.btn_Calculate.Location = New System.Drawing.Point(42, 126)
        Me.btn_Calculate.Name = "btn_Calculate"
        Me.btn_Calculate.Size = New System.Drawing.Size(75, 23)
        Me.btn_Calculate.TabIndex = 4
        Me.btn_Calculate.Text = "Calculate"
        Me.btn_Calculate.UseVisualStyleBackColor = True
        '
        'btn_Close
        '
        Me.btn_Close.Location = New System.Drawing.Point(148, 126)
        Me.btn_Close.Name = "btn_Close"
        Me.btn_Close.Size = New System.Drawing.Size(75, 23)
        Me.btn_Close.TabIndex = 5
        Me.btn_Close.Text = "Exit"
        Me.btn_Close.UseVisualStyleBackColor = True
        '
        'txt_OrgPrice
        '
        Me.txt_OrgPrice.Location = New System.Drawing.Point(162, 12)
        Me.txt_OrgPrice.Name = "txt_OrgPrice"
        Me.txt_OrgPrice.Size = New System.Drawing.Size(100, 20)
        Me.txt_OrgPrice.TabIndex = 6
        '
        'txt_Discount
        '
        Me.txt_Discount.Location = New System.Drawing.Point(162, 42)
        Me.txt_Discount.Name = "txt_Discount"
        Me.txt_Discount.Size = New System.Drawing.Size(100, 20)
        Me.txt_Discount.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(274, 171)
        Me.Controls.Add(Me.txt_Discount)
        Me.Controls.Add(Me.txt_OrgPrice)
        Me.Controls.Add(Me.btn_Close)
        Me.Controls.Add(Me.btn_Calculate)
        Me.Controls.Add(Me.lbl_NewPrice)
        Me.Controls.Add(Me.lbl_Sale)
        Me.Controls.Add(Me.lbl_Discount)
        Me.Controls.Add(Me.lbl_OrgPrice)
        Me.Name = "Form1"
        Me.Text = "Sale Price Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_OrgPrice As Label
    Friend WithEvents lbl_Discount As Label
    Friend WithEvents lbl_Sale As Label
    Friend WithEvents lbl_NewPrice As Label
    Friend WithEvents btn_Calculate As Button
    Friend WithEvents btn_Close As Button
    Friend WithEvents txt_OrgPrice As TextBox
    Friend WithEvents txt_Discount As TextBox
End Class
