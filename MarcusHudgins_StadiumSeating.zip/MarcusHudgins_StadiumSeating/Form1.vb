﻿Public Class Form1
    Private Sub btn_CalRev_Click(sender As Object, e As EventArgs) Handles btn_CalRev.Click
        Dim classA, classB, classC, revenue As Double
        classA = txt_InputA.Text * 15
        classB = txt_InputB.Text * 12
        classC = txt_InputC.Text * 9
        revenue = classA + classB + classC

        lbl_OutputA.Text = classA.ToString("c")
        lbl_OutputB.Text = classB.ToString("c")
        lbl_OutputC.Text = classC.ToString("c")
        lbl_RevOutput.Text = revenue.ToString("c")
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        txt_InputA.Clear()
        txt_InputB.Clear()
        txt_InputC.Clear()

        lbl_OutputA.Text = String.Empty
        lbl_OutputB.Text = String.Empty
        lbl_OutputC.Text = String.Empty
        lbl_RevOutput.Text = String.Empty
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub
End Class