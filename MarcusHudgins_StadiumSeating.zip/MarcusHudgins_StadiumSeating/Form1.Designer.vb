﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_Title = New System.Windows.Forms.Label()
        Me.lbl_ClassASold = New System.Windows.Forms.Label()
        Me.lbl_ClassBSold = New System.Windows.Forms.Label()
        Me.lbl_ClassCSold = New System.Windows.Forms.Label()
        Me.txt_InputA = New System.Windows.Forms.TextBox()
        Me.txt_InputB = New System.Windows.Forms.TextBox()
        Me.txt_InputC = New System.Windows.Forms.TextBox()
        Me.lbl_ClassARev = New System.Windows.Forms.Label()
        Me.lbl_ClassBRev = New System.Windows.Forms.Label()
        Me.lbl_ClassCRev = New System.Windows.Forms.Label()
        Me.lbl_TotalRev = New System.Windows.Forms.Label()
        Me.lbl_OutputA = New System.Windows.Forms.Label()
        Me.lbl_OutputB = New System.Windows.Forms.Label()
        Me.lbl_OutputC = New System.Windows.Forms.Label()
        Me.lbl_RevOutput = New System.Windows.Forms.Label()
        Me.btn_CalRev = New System.Windows.Forms.Button()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.grb_TicketSold = New System.Windows.Forms.GroupBox()
        Me.grb_RevenueGenerated = New System.Windows.Forms.GroupBox()
        Me.grb_TicketSold.SuspendLayout()
        Me.grb_RevenueGenerated.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl_Title
        '
        Me.lbl_Title.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Title.Location = New System.Drawing.Point(6, 62)
        Me.lbl_Title.Name = "lbl_Title"
        Me.lbl_Title.Size = New System.Drawing.Size(270, 46)
        Me.lbl_Title.TabIndex = 1
        Me.lbl_Title.Text = "Enter the number of tickets sold for each class of seats."
        '
        'lbl_ClassASold
        '
        Me.lbl_ClassASold.AutoSize = True
        Me.lbl_ClassASold.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ClassASold.Location = New System.Drawing.Point(86, 144)
        Me.lbl_ClassASold.Name = "lbl_ClassASold"
        Me.lbl_ClassASold.Size = New System.Drawing.Size(75, 20)
        Me.lbl_ClassASold.TabIndex = 2
        Me.lbl_ClassASold.Text = "Class A:"
        '
        'lbl_ClassBSold
        '
        Me.lbl_ClassBSold.AutoSize = True
        Me.lbl_ClassBSold.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ClassBSold.Location = New System.Drawing.Point(86, 197)
        Me.lbl_ClassBSold.Name = "lbl_ClassBSold"
        Me.lbl_ClassBSold.Size = New System.Drawing.Size(75, 20)
        Me.lbl_ClassBSold.TabIndex = 3
        Me.lbl_ClassBSold.Text = "Class B:"
        '
        'lbl_ClassCSold
        '
        Me.lbl_ClassCSold.AutoSize = True
        Me.lbl_ClassCSold.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ClassCSold.Location = New System.Drawing.Point(86, 244)
        Me.lbl_ClassCSold.Name = "lbl_ClassCSold"
        Me.lbl_ClassCSold.Size = New System.Drawing.Size(75, 20)
        Me.lbl_ClassCSold.TabIndex = 4
        Me.lbl_ClassCSold.Text = "Class C:"
        '
        'txt_InputA
        '
        Me.txt_InputA.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_InputA.Location = New System.Drawing.Point(167, 138)
        Me.txt_InputA.Name = "txt_InputA"
        Me.txt_InputA.Size = New System.Drawing.Size(100, 26)
        Me.txt_InputA.TabIndex = 5
        '
        'txt_InputB
        '
        Me.txt_InputB.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_InputB.Location = New System.Drawing.Point(167, 191)
        Me.txt_InputB.Name = "txt_InputB"
        Me.txt_InputB.Size = New System.Drawing.Size(100, 26)
        Me.txt_InputB.TabIndex = 6
        '
        'txt_InputC
        '
        Me.txt_InputC.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_InputC.Location = New System.Drawing.Point(167, 238)
        Me.txt_InputC.Name = "txt_InputC"
        Me.txt_InputC.Size = New System.Drawing.Size(100, 26)
        Me.txt_InputC.TabIndex = 7
        '
        'lbl_ClassARev
        '
        Me.lbl_ClassARev.AutoSize = True
        Me.lbl_ClassARev.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_ClassARev.Location = New System.Drawing.Point(86, 88)
        Me.lbl_ClassARev.Name = "lbl_ClassARev"
        Me.lbl_ClassARev.Size = New System.Drawing.Size(75, 20)
        Me.lbl_ClassARev.TabIndex = 9
        Me.lbl_ClassARev.Text = "Class A:"
        '
        'lbl_ClassBRev
        '
        Me.lbl_ClassBRev.AutoSize = True
        Me.lbl_ClassBRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ClassBRev.Location = New System.Drawing.Point(86, 138)
        Me.lbl_ClassBRev.Name = "lbl_ClassBRev"
        Me.lbl_ClassBRev.Size = New System.Drawing.Size(75, 20)
        Me.lbl_ClassBRev.TabIndex = 10
        Me.lbl_ClassBRev.Text = "Class B:"
        '
        'lbl_ClassCRev
        '
        Me.lbl_ClassCRev.AutoSize = True
        Me.lbl_ClassCRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ClassCRev.Location = New System.Drawing.Point(86, 184)
        Me.lbl_ClassCRev.Name = "lbl_ClassCRev"
        Me.lbl_ClassCRev.Size = New System.Drawing.Size(75, 20)
        Me.lbl_ClassCRev.TabIndex = 11
        Me.lbl_ClassCRev.Text = "Class C:"
        '
        'lbl_TotalRev
        '
        Me.lbl_TotalRev.AutoSize = True
        Me.lbl_TotalRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TotalRev.Location = New System.Drawing.Point(31, 241)
        Me.lbl_TotalRev.Name = "lbl_TotalRev"
        Me.lbl_TotalRev.Size = New System.Drawing.Size(130, 20)
        Me.lbl_TotalRev.TabIndex = 12
        Me.lbl_TotalRev.Text = "Total Revenue:"
        '
        'lbl_OutputA
        '
        Me.lbl_OutputA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_OutputA.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_OutputA.Location = New System.Drawing.Point(167, 82)
        Me.lbl_OutputA.Name = "lbl_OutputA"
        Me.lbl_OutputA.Size = New System.Drawing.Size(100, 26)
        Me.lbl_OutputA.TabIndex = 13
        '
        'lbl_OutputB
        '
        Me.lbl_OutputB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_OutputB.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_OutputB.Location = New System.Drawing.Point(167, 131)
        Me.lbl_OutputB.Name = "lbl_OutputB"
        Me.lbl_OutputB.Size = New System.Drawing.Size(100, 27)
        Me.lbl_OutputB.TabIndex = 14
        '
        'lbl_OutputC
        '
        Me.lbl_OutputC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_OutputC.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_OutputC.Location = New System.Drawing.Point(167, 178)
        Me.lbl_OutputC.Name = "lbl_OutputC"
        Me.lbl_OutputC.Size = New System.Drawing.Size(100, 26)
        Me.lbl_OutputC.TabIndex = 15
        '
        'lbl_RevOutput
        '
        Me.lbl_RevOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_RevOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_RevOutput.Location = New System.Drawing.Point(167, 235)
        Me.lbl_RevOutput.Name = "lbl_RevOutput"
        Me.lbl_RevOutput.Size = New System.Drawing.Size(100, 26)
        Me.lbl_RevOutput.TabIndex = 16
        '
        'btn_CalRev
        '
        Me.btn_CalRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_CalRev.Location = New System.Drawing.Point(123, 467)
        Me.btn_CalRev.Name = "btn_CalRev"
        Me.btn_CalRev.Size = New System.Drawing.Size(177, 45)
        Me.btn_CalRev.TabIndex = 17
        Me.btn_CalRev.Text = "Calculate Revenue"
        Me.btn_CalRev.UseVisualStyleBackColor = True
        '
        'btn_Clear
        '
        Me.btn_Clear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Clear.Location = New System.Drawing.Point(446, 467)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(112, 45)
        Me.btn_Clear.TabIndex = 18
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Exit.Location = New System.Drawing.Point(673, 467)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(112, 45)
        Me.btn_Exit.TabIndex = 19
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'grb_TicketSold
        '
        Me.grb_TicketSold.Controls.Add(Me.lbl_Title)
        Me.grb_TicketSold.Controls.Add(Me.lbl_ClassASold)
        Me.grb_TicketSold.Controls.Add(Me.txt_InputA)
        Me.grb_TicketSold.Controls.Add(Me.lbl_ClassBSold)
        Me.grb_TicketSold.Controls.Add(Me.txt_InputB)
        Me.grb_TicketSold.Controls.Add(Me.lbl_ClassCSold)
        Me.grb_TicketSold.Controls.Add(Me.txt_InputC)
        Me.grb_TicketSold.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grb_TicketSold.Location = New System.Drawing.Point(123, 56)
        Me.grb_TicketSold.Name = "grb_TicketSold"
        Me.grb_TicketSold.Size = New System.Drawing.Size(321, 308)
        Me.grb_TicketSold.TabIndex = 20
        Me.grb_TicketSold.TabStop = False
        Me.grb_TicketSold.Text = "Tickets Sold"
        '
        'grb_RevenueGenerated
        '
        Me.grb_RevenueGenerated.Controls.Add(Me.lbl_ClassARev)
        Me.grb_RevenueGenerated.Controls.Add(Me.lbl_OutputA)
        Me.grb_RevenueGenerated.Controls.Add(Me.lbl_ClassBRev)
        Me.grb_RevenueGenerated.Controls.Add(Me.lbl_OutputB)
        Me.grb_RevenueGenerated.Controls.Add(Me.lbl_ClassCRev)
        Me.grb_RevenueGenerated.Controls.Add(Me.lbl_RevOutput)
        Me.grb_RevenueGenerated.Controls.Add(Me.lbl_OutputC)
        Me.grb_RevenueGenerated.Controls.Add(Me.lbl_TotalRev)
        Me.grb_RevenueGenerated.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grb_RevenueGenerated.Location = New System.Drawing.Point(464, 56)
        Me.grb_RevenueGenerated.Name = "grb_RevenueGenerated"
        Me.grb_RevenueGenerated.Size = New System.Drawing.Size(321, 308)
        Me.grb_RevenueGenerated.TabIndex = 21
        Me.grb_RevenueGenerated.TabStop = False
        Me.grb_RevenueGenerated.Text = "Revenue Generated"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(987, 537)
        Me.Controls.Add(Me.grb_RevenueGenerated)
        Me.Controls.Add(Me.grb_TicketSold)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.btn_Clear)
        Me.Controls.Add(Me.btn_CalRev)
        Me.Name = "Form1"
        Me.Text = "Stadium Seating"
        Me.grb_TicketSold.ResumeLayout(False)
        Me.grb_TicketSold.PerformLayout()
        Me.grb_RevenueGenerated.ResumeLayout(False)
        Me.grb_RevenueGenerated.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lbl_Title As Label
    Friend WithEvents lbl_ClassASold As Label
    Friend WithEvents lbl_ClassBSold As Label
    Friend WithEvents lbl_ClassCSold As Label
    Friend WithEvents txt_InputA As TextBox
    Friend WithEvents txt_InputB As TextBox
    Friend WithEvents txt_InputC As TextBox
    Friend WithEvents lbl_ClassARev As Label
    Friend WithEvents lbl_ClassBRev As Label
    Friend WithEvents lbl_ClassCRev As Label
    Friend WithEvents lbl_TotalRev As Label
    Friend WithEvents lbl_OutputA As Label
    Friend WithEvents lbl_OutputB As Label
    Friend WithEvents lbl_OutputC As Label
    Friend WithEvents lbl_RevOutput As Label
    Friend WithEvents btn_CalRev As Button
    Friend WithEvents btn_Clear As Button
    Friend WithEvents btn_Exit As Button
    Friend WithEvents grb_TicketSold As GroupBox
    Friend WithEvents grb_RevenueGenerated As GroupBox
End Class
