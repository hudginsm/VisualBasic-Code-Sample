﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Creates the variable that will hold the running total for the licensing
        Dim LicensingTotal As Double = 0
        'Figures out which licensing type was choosen
        If radYearly.Checked = True Then
            LicensingTotal += 5000
            lblSoftwareLicense.Text = LicensingTotal.ToString("c")
        ElseIf radOneTime.Checked = True Then
            LicensingTotal += 20000
            lblSoftwareLicense.Text = LicensingTotal.ToString("c")
        End If
        'Creates the variable that will hold the running total for the added options
        Dim OptTotal As Double = 0
        'Finds out which options are selected
        If chkLevel3Support.Checked = True Then
            OptTotal += 3500
            lblOptionalFeatures.Text = OptTotal.ToString("c")
        End If
        If chkTraining.Checked = True Then
            OptTotal += 2000
            lblOptionalFeatures.Text = OptTotal.ToString("c")
        End If
        If chkBackup.Checked = True Then
            OptTotal += 300
            lblOptionalFeatures.Text = OptTotal.ToString("c")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clears the radian buttons
        radOneTime.Checked = False
        radYearly.Checked = False
        'Clears the checkboxes
        chkBackup.Checked = False
        chkLevel3Support.Checked = False
        chkTraining.Checked = False
        'Clears the output labels
        lblOptionalFeatures.Text = String.Empty
        lblSoftwareLicense.Text = String.Empty
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'Closes the application
        Me.Close()
    End Sub
End Class
