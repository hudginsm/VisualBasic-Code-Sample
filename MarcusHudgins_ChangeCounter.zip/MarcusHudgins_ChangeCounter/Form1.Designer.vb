﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lbl_Title = New System.Windows.Forms.Label()
        Me.lbl_TotalLabel = New System.Windows.Forms.Label()
        Me.lbl_TotalHolder = New System.Windows.Forms.Label()
        Me.pic_FiveCents = New System.Windows.Forms.PictureBox()
        Me.pic_TenCents = New System.Windows.Forms.PictureBox()
        Me.pic_TwentFiveCents = New System.Windows.Forms.PictureBox()
        Me.pic_FiftyCents = New System.Windows.Forms.PictureBox()
        Me.btn_Close = New System.Windows.Forms.Button()
        CType(Me.pic_FiveCents, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_TenCents, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_TwentFiveCents, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_FiftyCents, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_Title
        '
        Me.lbl_Title.AutoSize = True
        Me.lbl_Title.Location = New System.Drawing.Point(107, 19)
        Me.lbl_Title.Name = "lbl_Title"
        Me.lbl_Title.Size = New System.Drawing.Size(81, 13)
        Me.lbl_Title.TabIndex = 0
        Me.lbl_Title.Text = "Click The Coins"
        '
        'lbl_TotalLabel
        '
        Me.lbl_TotalLabel.AutoSize = True
        Me.lbl_TotalLabel.Location = New System.Drawing.Point(90, 254)
        Me.lbl_TotalLabel.Name = "lbl_TotalLabel"
        Me.lbl_TotalLabel.Size = New System.Drawing.Size(31, 13)
        Me.lbl_TotalLabel.TabIndex = 1
        Me.lbl_TotalLabel.Text = "Total"
        '
        'lbl_TotalHolder
        '
        Me.lbl_TotalHolder.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_TotalHolder.Location = New System.Drawing.Point(146, 253)
        Me.lbl_TotalHolder.Name = "lbl_TotalHolder"
        Me.lbl_TotalHolder.Size = New System.Drawing.Size(77, 26)
        Me.lbl_TotalHolder.TabIndex = 2
        '
        'pic_FiveCents
        '
        Me.pic_FiveCents.Image = CType(resources.GetObject("pic_FiveCents.Image"), System.Drawing.Image)
        Me.pic_FiveCents.Location = New System.Drawing.Point(32, 35)
        Me.pic_FiveCents.Name = "pic_FiveCents"
        Me.pic_FiveCents.Size = New System.Drawing.Size(109, 109)
        Me.pic_FiveCents.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_FiveCents.TabIndex = 3
        Me.pic_FiveCents.TabStop = False
        '
        'pic_TenCents
        '
        Me.pic_TenCents.Image = CType(resources.GetObject("pic_TenCents.Image"), System.Drawing.Image)
        Me.pic_TenCents.Location = New System.Drawing.Point(161, 35)
        Me.pic_TenCents.Name = "pic_TenCents"
        Me.pic_TenCents.Size = New System.Drawing.Size(107, 109)
        Me.pic_TenCents.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_TenCents.TabIndex = 4
        Me.pic_TenCents.TabStop = False
        '
        'pic_TwentFiveCents
        '
        Me.pic_TwentFiveCents.Image = CType(resources.GetObject("pic_TwentFiveCents.Image"), System.Drawing.Image)
        Me.pic_TwentFiveCents.Location = New System.Drawing.Point(32, 150)
        Me.pic_TwentFiveCents.Name = "pic_TwentFiveCents"
        Me.pic_TwentFiveCents.Size = New System.Drawing.Size(109, 100)
        Me.pic_TwentFiveCents.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_TwentFiveCents.TabIndex = 5
        Me.pic_TwentFiveCents.TabStop = False
        '
        'pic_FiftyCents
        '
        Me.pic_FiftyCents.Image = CType(resources.GetObject("pic_FiftyCents.Image"), System.Drawing.Image)
        Me.pic_FiftyCents.Location = New System.Drawing.Point(161, 150)
        Me.pic_FiftyCents.Name = "pic_FiftyCents"
        Me.pic_FiftyCents.Size = New System.Drawing.Size(107, 100)
        Me.pic_FiftyCents.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_FiftyCents.TabIndex = 6
        Me.pic_FiftyCents.TabStop = False
        '
        'btn_Close
        '
        Me.btn_Close.Location = New System.Drawing.Point(110, 285)
        Me.btn_Close.Name = "btn_Close"
        Me.btn_Close.Size = New System.Drawing.Size(75, 23)
        Me.btn_Close.TabIndex = 7
        Me.btn_Close.Text = "Exit"
        Me.btn_Close.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(304, 329)
        Me.Controls.Add(Me.btn_Close)
        Me.Controls.Add(Me.pic_FiftyCents)
        Me.Controls.Add(Me.pic_TwentFiveCents)
        Me.Controls.Add(Me.pic_TenCents)
        Me.Controls.Add(Me.pic_FiveCents)
        Me.Controls.Add(Me.lbl_TotalHolder)
        Me.Controls.Add(Me.lbl_TotalLabel)
        Me.Controls.Add(Me.lbl_Title)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.pic_FiveCents, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_TenCents, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_TwentFiveCents, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_FiftyCents, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_Title As Label
    Friend WithEvents lbl_TotalLabel As Label
    Friend WithEvents lbl_TotalHolder As Label
    Friend WithEvents pic_FiveCents As PictureBox
    Friend WithEvents pic_TenCents As PictureBox
    Friend WithEvents pic_TwentFiveCents As PictureBox
    Friend WithEvents pic_FiftyCents As PictureBox
    Friend WithEvents btn_Close As Button
End Class
