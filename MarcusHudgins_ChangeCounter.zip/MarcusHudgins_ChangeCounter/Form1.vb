﻿Public Class Form1
    Dim total As Double = 0.0

    Private Sub btn_Close_Click(sender As Object, e As EventArgs) Handles btn_Close.Click
        Me.Close()
    End Sub

    Private Sub pic_FiveCents_Click(sender As Object, e As EventArgs) Handles pic_FiveCents.Click
        total = total + 0.05
        lbl_TotalHolder.Text = total.ToString("c")
    End Sub

    Private Sub pic_TenCents_Click(sender As Object, e As EventArgs) Handles pic_TenCents.Click
        total = total + 0.1
        lbl_TotalHolder.Text = total.ToString("c")
    End Sub

    Private Sub pic_TwentFiveCents_Click(sender As Object, e As EventArgs) Handles pic_TwentFiveCents.Click
        total = total + 0.25
        lbl_TotalHolder.Text = total.ToString("c")
    End Sub

    Private Sub pic_FiftyCents_Click(sender As Object, e As EventArgs) Handles pic_FiftyCents.Click
        total = total + 0.5
        lbl_TotalHolder.Text = total.ToString("c")
    End Sub
End Class
