﻿Public Class Form1
    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub

    Private Sub btn_Sinister_Click(sender As Object, e As EventArgs) Handles btn_Sinister.Click
        lbl_Display.Text = "Left"
    End Sub

    Private Sub btn_Dexter_Click(sender As Object, e As EventArgs) Handles btn_Dexter.Click
        lbl_Display.Text = "Right"
    End Sub

    Private Sub btn_Medium_Click(sender As Object, e As EventArgs) Handles btn_Medium.Click
        lbl_Display.Text = "Middle"
    End Sub
End Class
