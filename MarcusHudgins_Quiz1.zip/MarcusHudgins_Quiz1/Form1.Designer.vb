﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_Sinister = New System.Windows.Forms.Button()
        Me.btn_Dexter = New System.Windows.Forms.Button()
        Me.btn_Medium = New System.Windows.Forms.Button()
        Me.lbl_Display = New System.Windows.Forms.Label()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_Sinister
        '
        Me.btn_Sinister.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btn_Sinister.Location = New System.Drawing.Point(9, 163)
        Me.btn_Sinister.Name = "btn_Sinister"
        Me.btn_Sinister.Size = New System.Drawing.Size(75, 32)
        Me.btn_Sinister.TabIndex = 0
        Me.btn_Sinister.Text = "Sinister"
        Me.btn_Sinister.UseVisualStyleBackColor = True
        '
        'btn_Dexter
        '
        Me.btn_Dexter.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btn_Dexter.Location = New System.Drawing.Point(90, 163)
        Me.btn_Dexter.Name = "btn_Dexter"
        Me.btn_Dexter.Size = New System.Drawing.Size(75, 32)
        Me.btn_Dexter.TabIndex = 1
        Me.btn_Dexter.Text = "Dexter"
        Me.btn_Dexter.UseVisualStyleBackColor = True
        '
        'btn_Medium
        '
        Me.btn_Medium.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btn_Medium.Location = New System.Drawing.Point(171, 163)
        Me.btn_Medium.Name = "btn_Medium"
        Me.btn_Medium.Size = New System.Drawing.Size(75, 32)
        Me.btn_Medium.TabIndex = 2
        Me.btn_Medium.Text = "Medium"
        Me.btn_Medium.UseVisualStyleBackColor = True
        '
        'lbl_Display
        '
        Me.lbl_Display.BackColor = System.Drawing.SystemColors.Control
        Me.lbl_Display.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Display.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.lbl_Display.Location = New System.Drawing.Point(9, 22)
        Me.lbl_Display.Name = "lbl_Display"
        Me.lbl_Display.Size = New System.Drawing.Size(237, 124)
        Me.lbl_Display.TabIndex = 3
        Me.lbl_Display.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_Exit
        '
        Me.btn_Exit.Location = New System.Drawing.Point(90, 226)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(75, 23)
        Me.btn_Exit.TabIndex = 4
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClientSize = New System.Drawing.Size(258, 261)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.lbl_Display)
        Me.Controls.Add(Me.btn_Medium)
        Me.Controls.Add(Me.btn_Dexter)
        Me.Controls.Add(Me.btn_Sinister)
        Me.Name = "Form1"
        Me.Text = "Latin Translator"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btn_Sinister As Button
    Friend WithEvents btn_Dexter As Button
    Friend WithEvents btn_Medium As Button
    Friend WithEvents lbl_Display As Label
    Friend WithEvents btn_Exit As Button
End Class
