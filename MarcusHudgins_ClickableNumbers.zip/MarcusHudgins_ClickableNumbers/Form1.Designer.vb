﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.pic_One = New System.Windows.Forms.PictureBox()
        Me.pic_Two = New System.Windows.Forms.PictureBox()
        Me.pic_Three = New System.Windows.Forms.PictureBox()
        Me.pic_Four = New System.Windows.Forms.PictureBox()
        Me.pic_Five = New System.Windows.Forms.PictureBox()
        CType(Me.pic_One, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_Two, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_Three, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_Four, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_Five, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pic_One
        '
        Me.pic_One.Image = CType(resources.GetObject("pic_One.Image"), System.Drawing.Image)
        Me.pic_One.Location = New System.Drawing.Point(29, 21)
        Me.pic_One.Name = "pic_One"
        Me.pic_One.Size = New System.Drawing.Size(82, 144)
        Me.pic_One.TabIndex = 0
        Me.pic_One.TabStop = False
        '
        'pic_Two
        '
        Me.pic_Two.Image = CType(resources.GetObject("pic_Two.Image"), System.Drawing.Image)
        Me.pic_Two.Location = New System.Drawing.Point(178, 21)
        Me.pic_Two.Name = "pic_Two"
        Me.pic_Two.Size = New System.Drawing.Size(82, 144)
        Me.pic_Two.TabIndex = 1
        Me.pic_Two.TabStop = False
        '
        'pic_Three
        '
        Me.pic_Three.Image = CType(resources.GetObject("pic_Three.Image"), System.Drawing.Image)
        Me.pic_Three.Location = New System.Drawing.Point(328, 21)
        Me.pic_Three.Name = "pic_Three"
        Me.pic_Three.Size = New System.Drawing.Size(81, 145)
        Me.pic_Three.TabIndex = 2
        Me.pic_Three.TabStop = False
        '
        'pic_Four
        '
        Me.pic_Four.Image = CType(resources.GetObject("pic_Four.Image"), System.Drawing.Image)
        Me.pic_Four.Location = New System.Drawing.Point(479, 21)
        Me.pic_Four.Name = "pic_Four"
        Me.pic_Four.Size = New System.Drawing.Size(82, 145)
        Me.pic_Four.TabIndex = 3
        Me.pic_Four.TabStop = False
        '
        'pic_Five
        '
        Me.pic_Five.Image = CType(resources.GetObject("pic_Five.Image"), System.Drawing.Image)
        Me.pic_Five.Location = New System.Drawing.Point(626, 21)
        Me.pic_Five.Name = "pic_Five"
        Me.pic_Five.Size = New System.Drawing.Size(81, 145)
        Me.pic_Five.TabIndex = 4
        Me.pic_Five.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(738, 193)
        Me.Controls.Add(Me.pic_Five)
        Me.Controls.Add(Me.pic_Four)
        Me.Controls.Add(Me.pic_Three)
        Me.Controls.Add(Me.pic_Two)
        Me.Controls.Add(Me.pic_One)
        Me.Name = "Form1"
        Me.Text = "Clickable Numbers"
        CType(Me.pic_One, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_Two, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_Three, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_Four, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_Five, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pic_One As PictureBox
    Friend WithEvents pic_Two As PictureBox
    Friend WithEvents pic_Three As PictureBox
    Friend WithEvents pic_Four As PictureBox
    Friend WithEvents pic_Five As PictureBox
End Class
