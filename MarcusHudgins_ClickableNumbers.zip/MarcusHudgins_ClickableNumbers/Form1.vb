﻿Public Class Form1
    Private Sub pic_One_Click(sender As Object, e As EventArgs) Handles pic_One.Click
        MessageBox.Show("One")
    End Sub

    Private Sub pic_Two_Click(sender As Object, e As EventArgs) Handles pic_Two.Click
        MessageBox.Show("Two")
    End Sub

    Private Sub pic_Three_Click(sender As Object, e As EventArgs) Handles pic_Three.Click
        MessageBox.Show("Three")
    End Sub

    Private Sub pic_Four_Click(sender As Object, e As EventArgs) Handles pic_Four.Click
        MessageBox.Show("Four")
    End Sub

    Private Sub pic_Five_Click(sender As Object, e As EventArgs) Handles pic_Five.Click
        MessageBox.Show("Five")
    End Sub
End Class
