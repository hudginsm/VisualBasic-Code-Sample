﻿Public Class Form1
    'Initalized a global variable to hold the running total 
    Dim Total As Double = 0
    Dim Days As Integer = 0
    Private Sub btn_Add_Click(sender As Object, e As EventArgs) Handles btn_Add.Click
        'Choosing which workshop was selected
        If lstWorkshop.SelectedIndex = 0 Then
            lstCosts.Items.Add("Handeling Stress -- 3 Days -- $595")
            Total = Total + 595
            Days = 3
        ElseIf lstWorkshop.SelectedIndex = 1 Then
            lstCosts.Items.Add("Time Management -- 3 Days -- $695")
            Total = Total + 695
            Days = 3
        ElseIf lstWorkshop.SelectedIndex = 2 Then
            lstCosts.Items.Add("Supervision Skills -- 3 Days -- $995")
            Total = Total + 995
            Days = 3
        ElseIf lstWorkshop.SelectedIndex = 3 Then
            lstCosts.Items.Add("Negotiation -- 5 Days -- $1,295")
            Total = Total + 1295
            Days = 5
        ElseIf lstWorkshop.SelectedIndex = 4 Then
            lstCosts.Items.Add("How to Interview -- 1 Day -- $395")
            Total = Total + 395
            Days = 1
        End If

        'Determaine the location selected
        If lstLocations.SelectedIndex = 0 Then
            lstCosts.Items.Add("Austin -- $95 per night")
            Total = Total + (95 * Days)
        ElseIf lstLocations.SelectedIndex = 1 Then
            lstCosts.Items.Add("Chicago -- $125 per night")
            Total = Total + (125 * Days)
        ElseIf lstLocations.SelectedIndex = 2 Then
            lstCosts.Items.Add("Dallas -- $110 per night")
            Total = Total + (110 * Days)
        ElseIf lstLocations.SelectedIndex = 3 Then
            lstCosts.Items.Add("Orlando -- $100 per night")
            Total = Total + (100 * Days)
        ElseIf lstLocations.SelectedIndex = 4 Then
            lstCosts.Items.Add("Phoenix -- $92 per night")
            Total = Total + (92 * Days)
        ElseIf lstLocations.SelectedIndex = 5 Then
            lstCosts.Items.Add("Raleigh -- $90 per night")
            Total = Total + (90 * Days)
        End If
    End Sub

    Private Sub btn_Total_Click(sender As Object, e As EventArgs) Handles btn_Total.Click
        lbl_Total.Text = Total.ToString("c")
    End Sub

    Private Sub btn_Reset_Click(sender As Object, e As EventArgs) Handles btn_Reset.Click
        lstWorkshop.SelectedIndex = -1
        lstLocations.SelectedIndex = -1
        lstCosts.Items.Clear()

        lbl_Total.Text = String.Empty

        Total = 0
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub
End Class
