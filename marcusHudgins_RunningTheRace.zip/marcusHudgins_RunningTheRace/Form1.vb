﻿Public Class Form1
    Private Sub btn_Calculate_Click(sender As Object, e As EventArgs) Handles btn_Calculate.Click
        If IsNumeric(txt_RunnerOneTime.Text) And IsNumeric(txt_RunnerTwoTime.Text) And IsNumeric(txt_RunnerThreeTime.Text) Then
            'Declartion and initalization of variables.
            Dim runnerOne, runnerTwo, runnerThree As Double
            runnerOne = txt_RunnerOneTime.Text
            runnerTwo = txt_RunnerTwoTime.Text
            runnerThree = txt_RunnerThreeTime.Text
            'Checks to see where runner one placed.
            If runnerOne < runnerTwo And runnerOne < runnerThree Then
                lbl_FirstPlace.Text = txt_RunnerOneName.Text
            ElseIf runnerOne < runnerTwo And runnerOne > runnerThree Then
                lbl_SecondPlace.Text = txt_RunnerOneName.Text
            ElseIf runnerOne > runnerTwo And runnerOne < runnerThree Then
                lbl_SecondPlace.Text = txt_RunnerOneName.Text
            ElseIf runnerOne > runnerTwo And runnerOne > runnerThree Then
                lbl_ThirdPlace.Text = txt_RunnerOneName.Text
            End If
            'Checks to see where runner two placed.
            If runnerTwo < runnerOne And runnerTwo < runnerThree Then
                lbl_FirstPlace.Text = txt_RunnerTwoName.Text
            ElseIf runnerTwo < runnerOne And runnerTwo > runnerThree Then
                lbl_SecondPlace.Text = txt_RunnerTwoName.Text
            ElseIf runnerTwo > runnerOne And runnerTwo < runnerThree Then
                lbl_SecondPlace.Text = txt_RunnerTwoName.Text
            ElseIf runnerTwo > runnerOne And runnerTwo > runnerThree Then
                lbl_ThirdPlace.Text = txt_RunnerTwoName.Text
            End If
            'Checks to see where runner three placed.
            If runnerThree < runnerOne And runnerThree < runnerTwo Then
                lbl_FirstPlace.Text = txt_RunnerThreeName.Text
            ElseIf runnerThree < runnerOne And runnerThree > runnerTwo Then
                lbl_SecondPlace.Text = txt_RunnerThreeName.Text
            ElseIf runnerThree > runnerOne And runnerThree < runnerTwo Then
                lbl_SecondPlace.Text = txt_RunnerThreeName.Text
            ElseIf runnerThree > runnerOne And runnerThree > runnerTwo Then
                lbl_ThirdPlace.Text = txt_RunnerThreeName.Text
            End If
        Else
            MessageBox.Show("ERROR!")
        End If
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        'Clears runner's names 
        txt_RunnerOneName.Clear()
        txt_RunnerTwoName.Clear()
        txt_RunnerThreeName.Clear()
        'Clears runner's time
        txt_RunnerOneTime.Clear()
        txt_RunnerTwoTime.Clear()
        txt_RunnerThreeTime.Clear()
        'Clears labels that hold placement
        lbl_FirstPlace.Text = String.Empty
        lbl_SecondPlace.Text = String.Empty
        lbl_ThirdPlace.Text = String.Empty
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        'Closes application
        Me.Close()
    End Sub

End Class
