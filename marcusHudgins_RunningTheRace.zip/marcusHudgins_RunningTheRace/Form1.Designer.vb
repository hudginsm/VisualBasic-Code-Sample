﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grb_RunnersNames = New System.Windows.Forms.GroupBox()
        Me.txt_RunnerThreeName = New System.Windows.Forms.TextBox()
        Me.txt_RunnerTwoName = New System.Windows.Forms.TextBox()
        Me.txt_RunnerOneName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grb_RunnersTimes = New System.Windows.Forms.GroupBox()
        Me.txt_RunnerThreeTime = New System.Windows.Forms.TextBox()
        Me.txt_RunnerTwoTime = New System.Windows.Forms.TextBox()
        Me.txt_RunnerOneTime = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.grb_RacersFinishingPlacement = New System.Windows.Forms.GroupBox()
        Me.lbl_ThirdPlace = New System.Windows.Forms.Label()
        Me.lbl_SecondPlace = New System.Windows.Forms.Label()
        Me.lbl_FirstPlace = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btn_Calculate = New System.Windows.Forms.Button()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.grb_RunnersNames.SuspendLayout()
        Me.grb_RunnersTimes.SuspendLayout()
        Me.grb_RacersFinishingPlacement.SuspendLayout()
        Me.SuspendLayout()
        '
        'grb_RunnersNames
        '
        Me.grb_RunnersNames.Controls.Add(Me.txt_RunnerThreeName)
        Me.grb_RunnersNames.Controls.Add(Me.txt_RunnerTwoName)
        Me.grb_RunnersNames.Controls.Add(Me.txt_RunnerOneName)
        Me.grb_RunnersNames.Controls.Add(Me.Label3)
        Me.grb_RunnersNames.Controls.Add(Me.Label2)
        Me.grb_RunnersNames.Controls.Add(Me.Label1)
        Me.grb_RunnersNames.Location = New System.Drawing.Point(12, 12)
        Me.grb_RunnersNames.Name = "grb_RunnersNames"
        Me.grb_RunnersNames.Size = New System.Drawing.Size(313, 229)
        Me.grb_RunnersNames.TabIndex = 0
        Me.grb_RunnersNames.TabStop = False
        Me.grb_RunnersNames.Text = "Runners' Names"
        '
        'txt_RunnerThreeName
        '
        Me.txt_RunnerThreeName.Location = New System.Drawing.Point(114, 161)
        Me.txt_RunnerThreeName.Name = "txt_RunnerThreeName"
        Me.txt_RunnerThreeName.Size = New System.Drawing.Size(100, 20)
        Me.txt_RunnerThreeName.TabIndex = 5
        '
        'txt_RunnerTwoName
        '
        Me.txt_RunnerTwoName.Location = New System.Drawing.Point(114, 109)
        Me.txt_RunnerTwoName.Name = "txt_RunnerTwoName"
        Me.txt_RunnerTwoName.Size = New System.Drawing.Size(100, 20)
        Me.txt_RunnerTwoName.TabIndex = 4
        '
        'txt_RunnerOneName
        '
        Me.txt_RunnerOneName.Location = New System.Drawing.Point(114, 54)
        Me.txt_RunnerOneName.Name = "txt_RunnerOneName"
        Me.txt_RunnerOneName.Size = New System.Drawing.Size(100, 20)
        Me.txt_RunnerOneName.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(37, 164)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Runner 3:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(37, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Runner 2:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(37, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Runner 1:"
        '
        'grb_RunnersTimes
        '
        Me.grb_RunnersTimes.Controls.Add(Me.txt_RunnerThreeTime)
        Me.grb_RunnersTimes.Controls.Add(Me.txt_RunnerTwoTime)
        Me.grb_RunnersTimes.Controls.Add(Me.txt_RunnerOneTime)
        Me.grb_RunnersTimes.Controls.Add(Me.Label6)
        Me.grb_RunnersTimes.Controls.Add(Me.Label5)
        Me.grb_RunnersTimes.Controls.Add(Me.Label4)
        Me.grb_RunnersTimes.Location = New System.Drawing.Point(366, 12)
        Me.grb_RunnersTimes.Name = "grb_RunnersTimes"
        Me.grb_RunnersTimes.Size = New System.Drawing.Size(313, 229)
        Me.grb_RunnersTimes.TabIndex = 0
        Me.grb_RunnersTimes.TabStop = False
        Me.grb_RunnersTimes.Text = "Runners' Times"
        '
        'txt_RunnerThreeTime
        '
        Me.txt_RunnerThreeTime.Location = New System.Drawing.Point(131, 161)
        Me.txt_RunnerThreeTime.Name = "txt_RunnerThreeTime"
        Me.txt_RunnerThreeTime.Size = New System.Drawing.Size(100, 20)
        Me.txt_RunnerThreeTime.TabIndex = 5
        '
        'txt_RunnerTwoTime
        '
        Me.txt_RunnerTwoTime.Location = New System.Drawing.Point(131, 109)
        Me.txt_RunnerTwoTime.Name = "txt_RunnerTwoTime"
        Me.txt_RunnerTwoTime.Size = New System.Drawing.Size(100, 20)
        Me.txt_RunnerTwoTime.TabIndex = 4
        '
        'txt_RunnerOneTime
        '
        Me.txt_RunnerOneTime.Location = New System.Drawing.Point(131, 54)
        Me.txt_RunnerOneTime.Name = "txt_RunnerOneTime"
        Me.txt_RunnerOneTime.Size = New System.Drawing.Size(100, 20)
        Me.txt_RunnerOneTime.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(42, 164)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Runner 3:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(42, 112)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Runner 2:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(42, 57)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Runner 1:"
        '
        'grb_RacersFinishingPlacement
        '
        Me.grb_RacersFinishingPlacement.Controls.Add(Me.lbl_ThirdPlace)
        Me.grb_RacersFinishingPlacement.Controls.Add(Me.lbl_SecondPlace)
        Me.grb_RacersFinishingPlacement.Controls.Add(Me.lbl_FirstPlace)
        Me.grb_RacersFinishingPlacement.Controls.Add(Me.Label9)
        Me.grb_RacersFinishingPlacement.Controls.Add(Me.Label8)
        Me.grb_RacersFinishingPlacement.Controls.Add(Me.Label7)
        Me.grb_RacersFinishingPlacement.Location = New System.Drawing.Point(12, 270)
        Me.grb_RacersFinishingPlacement.Name = "grb_RacersFinishingPlacement"
        Me.grb_RacersFinishingPlacement.Size = New System.Drawing.Size(313, 230)
        Me.grb_RacersFinishingPlacement.TabIndex = 0
        Me.grb_RacersFinishingPlacement.TabStop = False
        Me.grb_RacersFinishingPlacement.Text = "Racers' Finishing Placement"
        '
        'lbl_ThirdPlace
        '
        Me.lbl_ThirdPlace.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_ThirdPlace.Location = New System.Drawing.Point(114, 160)
        Me.lbl_ThirdPlace.Name = "lbl_ThirdPlace"
        Me.lbl_ThirdPlace.Size = New System.Drawing.Size(100, 23)
        Me.lbl_ThirdPlace.TabIndex = 7
        '
        'lbl_SecondPlace
        '
        Me.lbl_SecondPlace.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_SecondPlace.Location = New System.Drawing.Point(114, 101)
        Me.lbl_SecondPlace.Name = "lbl_SecondPlace"
        Me.lbl_SecondPlace.Size = New System.Drawing.Size(100, 23)
        Me.lbl_SecondPlace.TabIndex = 6
        '
        'lbl_FirstPlace
        '
        Me.lbl_FirstPlace.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_FirstPlace.Location = New System.Drawing.Point(114, 47)
        Me.lbl_FirstPlace.Name = "lbl_FirstPlace"
        Me.lbl_FirstPlace.Size = New System.Drawing.Size(100, 23)
        Me.lbl_FirstPlace.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(37, 170)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 13)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "3rd Place:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(37, 111)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(58, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "2nd Place:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(37, 57)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "1st Place:"
        '
        'btn_Calculate
        '
        Me.btn_Calculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Calculate.Location = New System.Drawing.Point(366, 270)
        Me.btn_Calculate.Name = "btn_Calculate"
        Me.btn_Calculate.Size = New System.Drawing.Size(313, 108)
        Me.btn_Calculate.TabIndex = 1
        Me.btn_Calculate.Text = "Calculate"
        Me.btn_Calculate.UseVisualStyleBackColor = True
        '
        'btn_Clear
        '
        Me.btn_Clear.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Clear.Location = New System.Drawing.Point(366, 393)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(152, 107)
        Me.btn_Clear.TabIndex = 2
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Exit.Location = New System.Drawing.Point(535, 393)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(144, 107)
        Me.btn_Exit.TabIndex = 3
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(691, 512)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.btn_Clear)
        Me.Controls.Add(Me.btn_Calculate)
        Me.Controls.Add(Me.grb_RunnersTimes)
        Me.Controls.Add(Me.grb_RunnersNames)
        Me.Controls.Add(Me.grb_RacersFinishingPlacement)
        Me.Name = "Form1"
        Me.Text = "Running The Race"
        Me.grb_RunnersNames.ResumeLayout(False)
        Me.grb_RunnersNames.PerformLayout()
        Me.grb_RunnersTimes.ResumeLayout(False)
        Me.grb_RunnersTimes.PerformLayout()
        Me.grb_RacersFinishingPlacement.ResumeLayout(False)
        Me.grb_RacersFinishingPlacement.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grb_RunnersNames As GroupBox
    Friend WithEvents grb_RunnersTimes As GroupBox
    Friend WithEvents grb_RacersFinishingPlacement As GroupBox
    Friend WithEvents btn_Calculate As Button
    Friend WithEvents btn_Clear As Button
    Friend WithEvents btn_Exit As Button
    Friend WithEvents txt_RunnerThreeName As TextBox
    Friend WithEvents txt_RunnerTwoName As TextBox
    Friend WithEvents txt_RunnerOneName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_RunnerThreeTime As TextBox
    Friend WithEvents txt_RunnerTwoTime As TextBox
    Friend WithEvents txt_RunnerOneTime As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lbl_ThirdPlace As Label
    Friend WithEvents lbl_SecondPlace As Label
    Friend WithEvents lbl_FirstPlace As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
End Class
