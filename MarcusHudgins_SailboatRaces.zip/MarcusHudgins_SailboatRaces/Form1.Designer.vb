﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_Title = New System.Windows.Forms.Label()
        Me.lbl_RaceOneHeader = New System.Windows.Forms.Label()
        Me.lbl_RaceTwoHeader = New System.Windows.Forms.Label()
        Me.lbl_RaceThreeHeader = New System.Windows.Forms.Label()
        Me.lbl_RaceFourHeader = New System.Windows.Forms.Label()
        Me.lbl_TotalHeader = New System.Windows.Forms.Label()
        Me.lbl_BoatOneHeader = New System.Windows.Forms.Label()
        Me.lbl_BoatTwoHeader = New System.Windows.Forms.Label()
        Me.lbl_BoatThreeHeader = New System.Windows.Forms.Label()
        Me.txt_BOneROne = New System.Windows.Forms.TextBox()
        Me.txt_BOneRTwo = New System.Windows.Forms.TextBox()
        Me.txt_BOneRThree = New System.Windows.Forms.TextBox()
        Me.txt_BOneRFour = New System.Windows.Forms.TextBox()
        Me.txt_BTwoROne = New System.Windows.Forms.TextBox()
        Me.txt_BTwoRTwo = New System.Windows.Forms.TextBox()
        Me.txt_BTwoRThree = New System.Windows.Forms.TextBox()
        Me.txt_BTwoRFour = New System.Windows.Forms.TextBox()
        Me.txt_BThreeROne = New System.Windows.Forms.TextBox()
        Me.txt_BThreeRTwo = New System.Windows.Forms.TextBox()
        Me.txt_BThreeRThree = New System.Windows.Forms.TextBox()
        Me.txt_BThreeRFour = New System.Windows.Forms.TextBox()
        Me.lbl_BoatOneTotal = New System.Windows.Forms.Label()
        Me.lbl_BoatTwoTotal = New System.Windows.Forms.Label()
        Me.lbl_BoatThreeTotal = New System.Windows.Forms.Label()
        Me.btn_Calaulate = New System.Windows.Forms.Button()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.btn_Close = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbl_Title
        '
        Me.lbl_Title.AutoSize = True
        Me.lbl_Title.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Title.Location = New System.Drawing.Point(12, 13)
        Me.lbl_Title.Name = "lbl_Title"
        Me.lbl_Title.Size = New System.Drawing.Size(83, 13)
        Me.lbl_Title.TabIndex = 0
        Me.lbl_Title.Text = "Race Results"
        '
        'lbl_RaceOneHeader
        '
        Me.lbl_RaceOneHeader.AutoSize = True
        Me.lbl_RaceOneHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_RaceOneHeader.Location = New System.Drawing.Point(64, 35)
        Me.lbl_RaceOneHeader.Name = "lbl_RaceOneHeader"
        Me.lbl_RaceOneHeader.Size = New System.Drawing.Size(48, 13)
        Me.lbl_RaceOneHeader.TabIndex = 1
        Me.lbl_RaceOneHeader.Text = "Race 1"
        '
        'lbl_RaceTwoHeader
        '
        Me.lbl_RaceTwoHeader.AutoSize = True
        Me.lbl_RaceTwoHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_RaceTwoHeader.Location = New System.Drawing.Point(118, 35)
        Me.lbl_RaceTwoHeader.Name = "lbl_RaceTwoHeader"
        Me.lbl_RaceTwoHeader.Size = New System.Drawing.Size(48, 13)
        Me.lbl_RaceTwoHeader.TabIndex = 2
        Me.lbl_RaceTwoHeader.Text = "Race 2"
        '
        'lbl_RaceThreeHeader
        '
        Me.lbl_RaceThreeHeader.AutoSize = True
        Me.lbl_RaceThreeHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_RaceThreeHeader.Location = New System.Drawing.Point(172, 35)
        Me.lbl_RaceThreeHeader.Name = "lbl_RaceThreeHeader"
        Me.lbl_RaceThreeHeader.Size = New System.Drawing.Size(48, 13)
        Me.lbl_RaceThreeHeader.TabIndex = 3
        Me.lbl_RaceThreeHeader.Text = "Rcae 3"
        '
        'lbl_RaceFourHeader
        '
        Me.lbl_RaceFourHeader.AutoSize = True
        Me.lbl_RaceFourHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_RaceFourHeader.Location = New System.Drawing.Point(226, 35)
        Me.lbl_RaceFourHeader.Name = "lbl_RaceFourHeader"
        Me.lbl_RaceFourHeader.Size = New System.Drawing.Size(48, 13)
        Me.lbl_RaceFourHeader.TabIndex = 4
        Me.lbl_RaceFourHeader.Text = "Race 4"
        '
        'lbl_TotalHeader
        '
        Me.lbl_TotalHeader.AutoSize = True
        Me.lbl_TotalHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TotalHeader.Location = New System.Drawing.Point(280, 35)
        Me.lbl_TotalHeader.Name = "lbl_TotalHeader"
        Me.lbl_TotalHeader.Size = New System.Drawing.Size(36, 13)
        Me.lbl_TotalHeader.TabIndex = 5
        Me.lbl_TotalHeader.Text = "Total"
        '
        'lbl_BoatOneHeader
        '
        Me.lbl_BoatOneHeader.AutoSize = True
        Me.lbl_BoatOneHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_BoatOneHeader.Location = New System.Drawing.Point(12, 62)
        Me.lbl_BoatOneHeader.Name = "lbl_BoatOneHeader"
        Me.lbl_BoatOneHeader.Size = New System.Drawing.Size(44, 13)
        Me.lbl_BoatOneHeader.TabIndex = 6
        Me.lbl_BoatOneHeader.Text = "Boat 1"
        '
        'lbl_BoatTwoHeader
        '
        Me.lbl_BoatTwoHeader.AutoSize = True
        Me.lbl_BoatTwoHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_BoatTwoHeader.Location = New System.Drawing.Point(12, 109)
        Me.lbl_BoatTwoHeader.Name = "lbl_BoatTwoHeader"
        Me.lbl_BoatTwoHeader.Size = New System.Drawing.Size(44, 13)
        Me.lbl_BoatTwoHeader.TabIndex = 7
        Me.lbl_BoatTwoHeader.Text = "Boat 2"
        '
        'lbl_BoatThreeHeader
        '
        Me.lbl_BoatThreeHeader.AutoSize = True
        Me.lbl_BoatThreeHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_BoatThreeHeader.Location = New System.Drawing.Point(12, 154)
        Me.lbl_BoatThreeHeader.Name = "lbl_BoatThreeHeader"
        Me.lbl_BoatThreeHeader.Size = New System.Drawing.Size(44, 13)
        Me.lbl_BoatThreeHeader.TabIndex = 8
        Me.lbl_BoatThreeHeader.Text = "Boat 3"
        '
        'txt_BOneROne
        '
        Me.txt_BOneROne.Location = New System.Drawing.Point(63, 61)
        Me.txt_BOneROne.Name = "txt_BOneROne"
        Me.txt_BOneROne.Size = New System.Drawing.Size(45, 20)
        Me.txt_BOneROne.TabIndex = 9
        '
        'txt_BOneRTwo
        '
        Me.txt_BOneRTwo.Location = New System.Drawing.Point(114, 62)
        Me.txt_BOneRTwo.Name = "txt_BOneRTwo"
        Me.txt_BOneRTwo.Size = New System.Drawing.Size(47, 20)
        Me.txt_BOneRTwo.TabIndex = 10
        '
        'txt_BOneRThree
        '
        Me.txt_BOneRThree.Location = New System.Drawing.Point(174, 62)
        Me.txt_BOneRThree.Name = "txt_BOneRThree"
        Me.txt_BOneRThree.Size = New System.Drawing.Size(46, 20)
        Me.txt_BOneRThree.TabIndex = 11
        '
        'txt_BOneRFour
        '
        Me.txt_BOneRFour.Location = New System.Drawing.Point(229, 62)
        Me.txt_BOneRFour.Name = "txt_BOneRFour"
        Me.txt_BOneRFour.Size = New System.Drawing.Size(46, 20)
        Me.txt_BOneRFour.TabIndex = 12
        '
        'txt_BTwoROne
        '
        Me.txt_BTwoROne.Location = New System.Drawing.Point(63, 106)
        Me.txt_BTwoROne.Name = "txt_BTwoROne"
        Me.txt_BTwoROne.Size = New System.Drawing.Size(45, 20)
        Me.txt_BTwoROne.TabIndex = 13
        '
        'txt_BTwoRTwo
        '
        Me.txt_BTwoRTwo.Location = New System.Drawing.Point(121, 106)
        Me.txt_BTwoRTwo.Name = "txt_BTwoRTwo"
        Me.txt_BTwoRTwo.Size = New System.Drawing.Size(47, 20)
        Me.txt_BTwoRTwo.TabIndex = 14
        '
        'txt_BTwoRThree
        '
        Me.txt_BTwoRThree.Location = New System.Drawing.Point(174, 106)
        Me.txt_BTwoRThree.Name = "txt_BTwoRThree"
        Me.txt_BTwoRThree.Size = New System.Drawing.Size(46, 20)
        Me.txt_BTwoRThree.TabIndex = 15
        '
        'txt_BTwoRFour
        '
        Me.txt_BTwoRFour.Location = New System.Drawing.Point(229, 106)
        Me.txt_BTwoRFour.Name = "txt_BTwoRFour"
        Me.txt_BTwoRFour.Size = New System.Drawing.Size(46, 20)
        Me.txt_BTwoRFour.TabIndex = 16
        '
        'txt_BThreeROne
        '
        Me.txt_BThreeROne.Location = New System.Drawing.Point(63, 151)
        Me.txt_BThreeROne.Name = "txt_BThreeROne"
        Me.txt_BThreeROne.Size = New System.Drawing.Size(45, 20)
        Me.txt_BThreeROne.TabIndex = 17
        '
        'txt_BThreeRTwo
        '
        Me.txt_BThreeRTwo.Location = New System.Drawing.Point(121, 151)
        Me.txt_BThreeRTwo.Name = "txt_BThreeRTwo"
        Me.txt_BThreeRTwo.Size = New System.Drawing.Size(47, 20)
        Me.txt_BThreeRTwo.TabIndex = 18
        '
        'txt_BThreeRThree
        '
        Me.txt_BThreeRThree.Location = New System.Drawing.Point(174, 151)
        Me.txt_BThreeRThree.Name = "txt_BThreeRThree"
        Me.txt_BThreeRThree.Size = New System.Drawing.Size(46, 20)
        Me.txt_BThreeRThree.TabIndex = 19
        '
        'txt_BThreeRFour
        '
        Me.txt_BThreeRFour.Location = New System.Drawing.Point(229, 151)
        Me.txt_BThreeRFour.Name = "txt_BThreeRFour"
        Me.txt_BThreeRFour.Size = New System.Drawing.Size(46, 20)
        Me.txt_BThreeRFour.TabIndex = 20
        '
        'lbl_BoatOneTotal
        '
        Me.lbl_BoatOneTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_BoatOneTotal.Location = New System.Drawing.Point(283, 62)
        Me.lbl_BoatOneTotal.Name = "lbl_BoatOneTotal"
        Me.lbl_BoatOneTotal.Size = New System.Drawing.Size(48, 20)
        Me.lbl_BoatOneTotal.TabIndex = 21
        '
        'lbl_BoatTwoTotal
        '
        Me.lbl_BoatTwoTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_BoatTwoTotal.Location = New System.Drawing.Point(283, 106)
        Me.lbl_BoatTwoTotal.Name = "lbl_BoatTwoTotal"
        Me.lbl_BoatTwoTotal.Size = New System.Drawing.Size(48, 20)
        Me.lbl_BoatTwoTotal.TabIndex = 22
        '
        'lbl_BoatThreeTotal
        '
        Me.lbl_BoatThreeTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_BoatThreeTotal.Location = New System.Drawing.Point(283, 153)
        Me.lbl_BoatThreeTotal.Name = "lbl_BoatThreeTotal"
        Me.lbl_BoatThreeTotal.Size = New System.Drawing.Size(48, 20)
        Me.lbl_BoatThreeTotal.TabIndex = 23
        '
        'btn_Calaulate
        '
        Me.btn_Calaulate.Location = New System.Drawing.Point(63, 190)
        Me.btn_Calaulate.Name = "btn_Calaulate"
        Me.btn_Calaulate.Size = New System.Drawing.Size(75, 40)
        Me.btn_Calaulate.TabIndex = 24
        Me.btn_Calaulate.Text = "Calculate Totals"
        Me.btn_Calaulate.UseVisualStyleBackColor = True
        '
        'btn_Clear
        '
        Me.btn_Clear.Location = New System.Drawing.Point(145, 190)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(75, 40)
        Me.btn_Clear.TabIndex = 25
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'btn_Close
        '
        Me.btn_Close.Location = New System.Drawing.Point(229, 190)
        Me.btn_Close.Name = "btn_Close"
        Me.btn_Close.Size = New System.Drawing.Size(75, 40)
        Me.btn_Close.TabIndex = 26
        Me.btn_Close.Text = "Close"
        Me.btn_Close.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(340, 242)
        Me.Controls.Add(Me.btn_Close)
        Me.Controls.Add(Me.btn_Clear)
        Me.Controls.Add(Me.btn_Calaulate)
        Me.Controls.Add(Me.lbl_BoatThreeTotal)
        Me.Controls.Add(Me.lbl_BoatTwoTotal)
        Me.Controls.Add(Me.lbl_BoatOneTotal)
        Me.Controls.Add(Me.txt_BThreeRFour)
        Me.Controls.Add(Me.txt_BThreeRThree)
        Me.Controls.Add(Me.txt_BThreeRTwo)
        Me.Controls.Add(Me.txt_BThreeROne)
        Me.Controls.Add(Me.txt_BTwoRFour)
        Me.Controls.Add(Me.txt_BTwoRThree)
        Me.Controls.Add(Me.txt_BTwoRTwo)
        Me.Controls.Add(Me.txt_BTwoROne)
        Me.Controls.Add(Me.txt_BOneRFour)
        Me.Controls.Add(Me.txt_BOneRThree)
        Me.Controls.Add(Me.txt_BOneRTwo)
        Me.Controls.Add(Me.txt_BOneROne)
        Me.Controls.Add(Me.lbl_BoatThreeHeader)
        Me.Controls.Add(Me.lbl_BoatTwoHeader)
        Me.Controls.Add(Me.lbl_BoatOneHeader)
        Me.Controls.Add(Me.lbl_TotalHeader)
        Me.Controls.Add(Me.lbl_RaceFourHeader)
        Me.Controls.Add(Me.lbl_RaceThreeHeader)
        Me.Controls.Add(Me.lbl_RaceTwoHeader)
        Me.Controls.Add(Me.lbl_RaceOneHeader)
        Me.Controls.Add(Me.lbl_Title)
        Me.Name = "Form1"
        Me.Text = "Sailboat Races"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_Title As Label
    Friend WithEvents lbl_RaceOneHeader As Label
    Friend WithEvents lbl_RaceTwoHeader As Label
    Friend WithEvents lbl_RaceThreeHeader As Label
    Friend WithEvents lbl_RaceFourHeader As Label
    Friend WithEvents lbl_TotalHeader As Label
    Friend WithEvents lbl_BoatOneHeader As Label
    Friend WithEvents lbl_BoatTwoHeader As Label
    Friend WithEvents lbl_BoatThreeHeader As Label
    Friend WithEvents txt_BOneROne As TextBox
    Friend WithEvents txt_BOneRTwo As TextBox
    Friend WithEvents txt_BOneRThree As TextBox
    Friend WithEvents txt_BOneRFour As TextBox
    Friend WithEvents txt_BTwoROne As TextBox
    Friend WithEvents txt_BTwoRTwo As TextBox
    Friend WithEvents txt_BTwoRThree As TextBox
    Friend WithEvents txt_BTwoRFour As TextBox
    Friend WithEvents txt_BThreeROne As TextBox
    Friend WithEvents txt_BThreeRTwo As TextBox
    Friend WithEvents txt_BThreeRThree As TextBox
    Friend WithEvents txt_BThreeRFour As TextBox
    Friend WithEvents lbl_BoatOneTotal As Label
    Friend WithEvents lbl_BoatTwoTotal As Label
    Friend WithEvents lbl_BoatThreeTotal As Label
    Friend WithEvents btn_Calaulate As Button
    Friend WithEvents btn_Clear As Button
    Friend WithEvents btn_Close As Button
End Class
