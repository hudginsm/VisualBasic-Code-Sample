﻿Public Class Form1
    Private Sub btn_Close_Click(sender As Object, e As EventArgs) Handles btn_Close.Click
        Me.Close()
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        txt_BOneROne.Clear()
        txt_BOneRTwo.Clear()
        txt_BOneRThree.Clear()
        txt_BOneRFour.Clear()

        txt_BTwoROne.Clear()
        txt_BTwoRTwo.Clear()
        txt_BTwoRThree.Clear()
        txt_BTwoRFour.Clear()

        txt_BThreeROne.Clear()
        txt_BThreeRTwo.Clear()
        txt_BThreeRThree.Clear()
        txt_BThreeRFour.Clear()

        lbl_BoatOneTotal.Text = String.Empty
        lbl_BoatTwoTotal.Text = String.Empty
        lbl_BoatThreeTotal.Text = String.Empty
    End Sub

    Private Sub btn_Calaulate_Click(sender As Object, e As EventArgs) Handles btn_Calaulate.Click
        Dim BoatOneTotal, BoatTwoTotal, BoatThreeTotal As Double
        BoatOneTotal = CDbl(txt_BOneROne.Text) + CDbl(txt_BOneRTwo.Text) + CDbl(txt_BOneRThree.Text) + CDbl(txt_BOneRFour.Text)
        BoatTwoTotal = CDbl(txt_BTwoROne.Text) + CDbl(txt_BTwoRTwo.Text) + CDbl(txt_BTwoRThree.Text) + CDbl(txt_BTwoRFour.Text)
        BoatThreeTotal = CDbl(txt_BThreeROne.Text) + CDbl(txt_BThreeRTwo.Text) + CDbl(txt_BThreeRThree.Text) + CDbl(txt_BThreeRFour.Text)

        lbl_BoatOneTotal.Text = BoatOneTotal
        lbl_BoatTwoTotal.Text = BoatTwoTotal
        lbl_BoatThreeTotal.Text = BoatTwoTotal

    End Sub
End Class
