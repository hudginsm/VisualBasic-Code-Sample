﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_Italian = New System.Windows.Forms.Button()
        Me.btn_Spanish = New System.Windows.Forms.Button()
        Me.btn_German = New System.Windows.Forms.Button()
        Me.lbl_Output = New System.Windows.Forms.Label()
        Me.lbl_Title = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn_Italian
        '
        Me.btn_Italian.Location = New System.Drawing.Point(86, 327)
        Me.btn_Italian.Name = "btn_Italian"
        Me.btn_Italian.Size = New System.Drawing.Size(75, 23)
        Me.btn_Italian.TabIndex = 0
        Me.btn_Italian.Text = "Italian"
        Me.btn_Italian.UseVisualStyleBackColor = True
        '
        'btn_Spanish
        '
        Me.btn_Spanish.Location = New System.Drawing.Point(269, 327)
        Me.btn_Spanish.Name = "btn_Spanish"
        Me.btn_Spanish.Size = New System.Drawing.Size(75, 23)
        Me.btn_Spanish.TabIndex = 1
        Me.btn_Spanish.Text = "Spanish"
        Me.btn_Spanish.UseVisualStyleBackColor = True
        '
        'btn_German
        '
        Me.btn_German.Location = New System.Drawing.Point(176, 393)
        Me.btn_German.Name = "btn_German"
        Me.btn_German.Size = New System.Drawing.Size(75, 23)
        Me.btn_German.TabIndex = 2
        Me.btn_German.Text = "German"
        Me.btn_German.UseVisualStyleBackColor = True
        '
        'lbl_Output
        '
        Me.lbl_Output.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lbl_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Output.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Output.Location = New System.Drawing.Point(86, 188)
        Me.lbl_Output.Name = "lbl_Output"
        Me.lbl_Output.Size = New System.Drawing.Size(258, 82)
        Me.lbl_Output.TabIndex = 3
        Me.lbl_Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_Title
        '
        Me.lbl_Title.AutoSize = True
        Me.lbl_Title.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Title.Location = New System.Drawing.Point(53, 129)
        Me.lbl_Title.Name = "lbl_Title"
        Me.lbl_Title.Size = New System.Drawing.Size(345, 20)
        Me.lbl_Title.TabIndex = 4
        Me.lbl_Title.Text = "Select the language and I wil say Good Morning"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(442, 534)
        Me.Controls.Add(Me.lbl_Title)
        Me.Controls.Add(Me.lbl_Output)
        Me.Controls.Add(Me.btn_German)
        Me.Controls.Add(Me.btn_Spanish)
        Me.Controls.Add(Me.btn_Italian)
        Me.Name = "Form1"
        Me.Text = "Language Translator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_Italian As Button
    Friend WithEvents btn_Spanish As Button
    Friend WithEvents btn_German As Button
    Friend WithEvents lbl_Output As Label
    Friend WithEvents lbl_Title As Label
End Class
