﻿Public Class Form1
    Private Sub btn_Italian_Click(sender As Object, e As EventArgs) Handles btn_Italian.Click
        lbl_Output.Text = "Buongiorno"
    End Sub

    Private Sub btn_Spanish_Click(sender As Object, e As EventArgs) Handles btn_Spanish.Click
        lbl_Output.Text = "Buenos Dias"
    End Sub

    Private Sub btn_German_Click(sender As Object, e As EventArgs) Handles btn_German.Click
        lbl_Output.Text = "Guten Morgen"
    End Sub


End Class
