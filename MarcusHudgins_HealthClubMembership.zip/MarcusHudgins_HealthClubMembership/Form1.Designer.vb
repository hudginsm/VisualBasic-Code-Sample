﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rad_Adult = New System.Windows.Forms.RadioButton()
        Me.rad_Child = New System.Windows.Forms.RadioButton()
        Me.rad_Student = New System.Windows.Forms.RadioButton()
        Me.rad_Senior = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chk_Yoga = New System.Windows.Forms.CheckBox()
        Me.chk_Karate = New System.Windows.Forms.CheckBox()
        Me.chk_Trainer = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_Months = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl_MonthlyFees = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lbl_TotalFee = New System.Windows.Forms.Label()
        Me.btn_Calculate = New System.Windows.Forms.Button()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rad_Adult)
        Me.GroupBox1.Controls.Add(Me.rad_Child)
        Me.GroupBox1.Controls.Add(Me.rad_Student)
        Me.GroupBox1.Controls.Add(Me.rad_Senior)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(130, 123)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Type of Membership"
        '
        'rad_Adult
        '
        Me.rad_Adult.AutoSize = True
        Me.rad_Adult.Location = New System.Drawing.Point(6, 29)
        Me.rad_Adult.Name = "rad_Adult"
        Me.rad_Adult.Size = New System.Drawing.Size(95, 17)
        Me.rad_Adult.TabIndex = 1
        Me.rad_Adult.TabStop = True
        Me.rad_Adult.Text = "Standard Adult"
        Me.rad_Adult.UseVisualStyleBackColor = True
        '
        'rad_Child
        '
        Me.rad_Child.AutoSize = True
        Me.rad_Child.Location = New System.Drawing.Point(6, 52)
        Me.rad_Child.Name = "rad_Child"
        Me.rad_Child.Size = New System.Drawing.Size(113, 17)
        Me.rad_Child.TabIndex = 2
        Me.rad_Child.TabStop = True
        Me.rad_Child.Text = "Child (12 & younger)"
        Me.rad_Child.UseVisualStyleBackColor = True
        '
        'rad_Student
        '
        Me.rad_Student.AutoSize = True
        Me.rad_Student.Location = New System.Drawing.Point(6, 75)
        Me.rad_Student.Name = "rad_Student"
        Me.rad_Student.Size = New System.Drawing.Size(62, 17)
        Me.rad_Student.TabIndex = 3
        Me.rad_Student.TabStop = True
        Me.rad_Student.Text = "Student"
        Me.rad_Student.UseVisualStyleBackColor = True
        '
        'rad_Senior
        '
        Me.rad_Senior.AutoSize = True
        Me.rad_Senior.Location = New System.Drawing.Point(6, 98)
        Me.rad_Senior.Name = "rad_Senior"
        Me.rad_Senior.Size = New System.Drawing.Size(89, 17)
        Me.rad_Senior.TabIndex = 4
        Me.rad_Senior.TabStop = True
        Me.rad_Senior.Text = "Senior Citizen"
        Me.rad_Senior.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chk_Yoga)
        Me.GroupBox2.Controls.Add(Me.chk_Karate)
        Me.GroupBox2.Controls.Add(Me.chk_Trainer)
        Me.GroupBox2.Location = New System.Drawing.Point(190, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(132, 123)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Options"
        '
        'chk_Yoga
        '
        Me.chk_Yoga.AutoSize = True
        Me.chk_Yoga.Location = New System.Drawing.Point(15, 29)
        Me.chk_Yoga.Name = "chk_Yoga"
        Me.chk_Yoga.Size = New System.Drawing.Size(51, 17)
        Me.chk_Yoga.TabIndex = 2
        Me.chk_Yoga.Text = "Yoga"
        Me.chk_Yoga.UseVisualStyleBackColor = True
        '
        'chk_Karate
        '
        Me.chk_Karate.AutoSize = True
        Me.chk_Karate.Location = New System.Drawing.Point(15, 52)
        Me.chk_Karate.Name = "chk_Karate"
        Me.chk_Karate.Size = New System.Drawing.Size(57, 17)
        Me.chk_Karate.TabIndex = 3
        Me.chk_Karate.Text = "Karate"
        Me.chk_Karate.UseVisualStyleBackColor = True
        '
        'chk_Trainer
        '
        Me.chk_Trainer.AutoSize = True
        Me.chk_Trainer.Location = New System.Drawing.Point(15, 75)
        Me.chk_Trainer.Name = "chk_Trainer"
        Me.chk_Trainer.Size = New System.Drawing.Size(103, 17)
        Me.chk_Trainer.TabIndex = 4
        Me.chk_Trainer.Text = "Personal Trainer"
        Me.chk_Trainer.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txt_Months)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 157)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(153, 110)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Membership Length"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter the Number of Months"
        '
        'txt_Months
        '
        Me.txt_Months.Location = New System.Drawing.Point(19, 67)
        Me.txt_Months.Name = "txt_Months"
        Me.txt_Months.Size = New System.Drawing.Size(100, 20)
        Me.txt_Months.TabIndex = 1
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.lbl_TotalFee)
        Me.GroupBox4.Controls.Add(Me.Label2)
        Me.GroupBox4.Controls.Add(Me.lbl_MonthlyFees)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Location = New System.Drawing.Point(190, 167)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(229, 100)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Membership Fees"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Monthly Fees:"
        '
        'lbl_MonthlyFees
        '
        Me.lbl_MonthlyFees.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_MonthlyFees.Location = New System.Drawing.Point(85, 22)
        Me.lbl_MonthlyFees.Name = "lbl_MonthlyFees"
        Me.lbl_MonthlyFees.Size = New System.Drawing.Size(100, 23)
        Me.lbl_MonthlyFees.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(45, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(34, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Total:"
        '
        'lbl_TotalFee
        '
        Me.lbl_TotalFee.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_TotalFee.Location = New System.Drawing.Point(85, 54)
        Me.lbl_TotalFee.Name = "lbl_TotalFee"
        Me.lbl_TotalFee.Size = New System.Drawing.Size(100, 23)
        Me.lbl_TotalFee.TabIndex = 7
        '
        'btn_Calculate
        '
        Me.btn_Calculate.Location = New System.Drawing.Point(66, 305)
        Me.btn_Calculate.Name = "btn_Calculate"
        Me.btn_Calculate.Size = New System.Drawing.Size(75, 23)
        Me.btn_Calculate.TabIndex = 4
        Me.btn_Calculate.Text = "Calculate"
        Me.btn_Calculate.UseVisualStyleBackColor = True
        '
        'btn_Clear
        '
        Me.btn_Clear.Location = New System.Drawing.Point(181, 305)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(75, 23)
        Me.btn_Clear.TabIndex = 5
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Location = New System.Drawing.Point(300, 305)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(75, 23)
        Me.btn_Exit.TabIndex = 6
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(436, 340)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.btn_Clear)
        Me.Controls.Add(Me.btn_Calculate)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Membership Fee Calculator"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rad_Adult As RadioButton
    Friend WithEvents rad_Child As RadioButton
    Friend WithEvents rad_Student As RadioButton
    Friend WithEvents rad_Senior As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chk_Yoga As CheckBox
    Friend WithEvents chk_Karate As CheckBox
    Friend WithEvents chk_Trainer As CheckBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_Months As TextBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents lbl_TotalFee As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lbl_MonthlyFees As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btn_Calculate As Button
    Friend WithEvents btn_Clear As Button
    Friend WithEvents btn_Exit As Button
End Class
