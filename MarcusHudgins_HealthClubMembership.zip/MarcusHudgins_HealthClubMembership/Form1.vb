﻿Public Class Form1
    Private Sub btn_Calculate_Click(sender As Object, e As EventArgs) Handles btn_Calculate.Click
        Dim numOfMonths As Integer = 1
        Dim MonthlyFees, TotalFees As Double
        MonthlyFees = 0
        TotalFees = 0

        'Radio Buttons'
        If rad_Adult.Checked = True Then
            MonthlyFees = 40.0
        ElseIf rad_Child.Checked = True Then
            MonthlyFees = 20.0
        ElseIf rad_Student.Checked = True Then
            MonthlyFees = 25.0
        ElseIf rad_Senior.Checked = True Then
            MonthlyFees = 18.0
        End If
        numOfMonths = txt_Months.Text
        MonthlyFees = MonthlyFees * numOfMonths

        'Checkboxes'
        If chk_Yoga.Checked = True Then
            MonthlyFees = MonthlyFees + 10.0
        End If
        If chk_Karate.Checked = True Then
            MonthlyFees = MonthlyFees + 30.0
        End If
        If chk_Trainer.Checked = True Then
            MonthlyFees = MonthlyFees + 50.0
        End If

        'display output to labels'
        numOfMonths = txt_Months.Text
        TotalFees = MonthlyFees + numOfMonths

        lbl_MonthlyFees.Text = MonthlyFees
        lbl_TotalFee.Text = TotalFees
    End Sub
End Class
