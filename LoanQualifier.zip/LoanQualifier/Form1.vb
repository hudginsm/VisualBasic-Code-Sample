﻿Public Class Form1
    Private Sub btn_Check_Click(sender As Object, e As EventArgs) Handles btn_Check.Click
        Dim username, password As String
        username = txt_Name.Text
        password = txt_Password.Text

        'CHECKS TO MAKE SURE THE TEXTBOX IS NOT EMPTY
        If username = String.Empty Or password = String.Empty Then
            lbl_QalifyStatus.Text = "Please enter a username or a password"
        ElseIf username.ToUpper <> "DBURRELL" Then
            lbl_QalifyStatus.Text = "Incorrect"
        ElseIf username.ToUpper = "DBURRELL" Then
            If password = "Happy" Then
                lbl_QalifyStatus.Text = "Correct"
            Else
                lbl_QalifyStatus.Text = "Incorrect"
            End If
        End If
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        txt_Name.Clear()
        txt_Password.Clear()

        lbl_QalifyStatus.Text = String.Empty
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub
End Class
