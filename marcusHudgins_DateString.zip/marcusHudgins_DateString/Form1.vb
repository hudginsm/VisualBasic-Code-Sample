﻿Public Class Form1
    Private Sub btn_Date_Click(sender As Object, e As EventArgs) Handles btn_Date.Click
        lblDateString.Text = txtDayOfWeek.Text & ", " & txtMonth.Text & " " & txtDayOfMonth.Text & ", " & txtYear.Text
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        txtDayOfWeek.Clear()
        txtMonth.Clear()
        txtDayOfMonth.Clear()
        txtYear.Clear()
        lblDateString.Text = String.Empty
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub
End Class
