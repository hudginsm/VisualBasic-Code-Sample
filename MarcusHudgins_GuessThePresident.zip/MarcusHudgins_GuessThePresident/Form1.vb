﻿Public Class Form1
    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub

    Private Sub btn_ShowAnswer_Click(sender As Object, e As EventArgs) Handles btn_ShowAnswer.Click
        lbl_Answer.Text = "Theodore Roosevelt"
    End Sub
End Class
