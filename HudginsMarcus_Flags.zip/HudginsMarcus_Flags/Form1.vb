﻿Public Class Form1
    Private Sub pic_Finland_Click(sender As Object, e As EventArgs) Handles pic_Finland.Click
        lbl_FlagName.Text = "Finland"
    End Sub

    Private Sub pic_France_Click(sender As Object, e As EventArgs) Handles pic_France.Click
        lbl_FlagName.Text = "France"
    End Sub

    Private Sub pic_Germany_Click(sender As Object, e As EventArgs) Handles pic_Germany.Click
        lbl_FlagName.Text = "Germany"
    End Sub
End Class
