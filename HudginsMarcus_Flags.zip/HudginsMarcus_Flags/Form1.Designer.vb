﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.pic_Finland = New System.Windows.Forms.PictureBox()
        Me.pic_France = New System.Windows.Forms.PictureBox()
        Me.pic_Germany = New System.Windows.Forms.PictureBox()
        Me.lbl_Title = New System.Windows.Forms.Label()
        Me.lbl_FlagName = New System.Windows.Forms.Label()
        CType(Me.pic_Finland, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_France, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_Germany, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pic_Finland
        '
        Me.pic_Finland.Image = CType(resources.GetObject("pic_Finland.Image"), System.Drawing.Image)
        Me.pic_Finland.Location = New System.Drawing.Point(63, 138)
        Me.pic_Finland.Name = "pic_Finland"
        Me.pic_Finland.Size = New System.Drawing.Size(169, 110)
        Me.pic_Finland.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_Finland.TabIndex = 0
        Me.pic_Finland.TabStop = False
        '
        'pic_France
        '
        Me.pic_France.Image = CType(resources.GetObject("pic_France.Image"), System.Drawing.Image)
        Me.pic_France.Location = New System.Drawing.Point(270, 138)
        Me.pic_France.Name = "pic_France"
        Me.pic_France.Size = New System.Drawing.Size(160, 110)
        Me.pic_France.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_France.TabIndex = 1
        Me.pic_France.TabStop = False
        '
        'pic_Germany
        '
        Me.pic_Germany.Image = CType(resources.GetObject("pic_Germany.Image"), System.Drawing.Image)
        Me.pic_Germany.Location = New System.Drawing.Point(467, 138)
        Me.pic_Germany.Name = "pic_Germany"
        Me.pic_Germany.Size = New System.Drawing.Size(149, 110)
        Me.pic_Germany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_Germany.TabIndex = 2
        Me.pic_Germany.TabStop = False
        '
        'lbl_Title
        '
        Me.lbl_Title.AutoSize = True
        Me.lbl_Title.Font = New System.Drawing.Font("Ravie", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Title.Location = New System.Drawing.Point(80, 59)
        Me.lbl_Title.Name = "lbl_Title"
        Me.lbl_Title.Size = New System.Drawing.Size(517, 22)
        Me.lbl_Title.TabIndex = 3
        Me.lbl_Title.Text = "Click a flag to see the name of the country"
        '
        'lbl_FlagName
        '
        Me.lbl_FlagName.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lbl_FlagName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_FlagName.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_FlagName.Location = New System.Drawing.Point(223, 340)
        Me.lbl_FlagName.Name = "lbl_FlagName"
        Me.lbl_FlagName.Size = New System.Drawing.Size(233, 34)
        Me.lbl_FlagName.TabIndex = 4
        Me.lbl_FlagName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Goldenrod
        Me.ClientSize = New System.Drawing.Size(727, 520)
        Me.Controls.Add(Me.lbl_FlagName)
        Me.Controls.Add(Me.lbl_Title)
        Me.Controls.Add(Me.pic_Germany)
        Me.Controls.Add(Me.pic_France)
        Me.Controls.Add(Me.pic_Finland)
        Me.Name = "Form1"
        Me.Text = "Flags"
        CType(Me.pic_Finland, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_France, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_Germany, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pic_Finland As PictureBox
    Friend WithEvents pic_France As PictureBox
    Friend WithEvents pic_Germany As PictureBox
    Friend WithEvents lbl_Title As Label
    Friend WithEvents lbl_FlagName As Label
End Class
