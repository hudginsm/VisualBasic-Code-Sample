﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_Addition = New System.Windows.Forms.Button()
        Me.btn_Subtraction = New System.Windows.Forms.Button()
        Me.btn_Multiplication = New System.Windows.Forms.Button()
        Me.btn_Exponential = New System.Windows.Forms.Button()
        Me.btn_Division = New System.Windows.Forms.Button()
        Me.btn_IntDivision = New System.Windows.Forms.Button()
        Me.btn_Modulus = New System.Windows.Forms.Button()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lbl_Answer = New System.Windows.Forms.Label()
        Me.txt_NumOne = New System.Windows.Forms.TextBox()
        Me.txt_NumTwo = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btn_Addition
        '
        Me.btn_Addition.Location = New System.Drawing.Point(12, 190)
        Me.btn_Addition.Name = "btn_Addition"
        Me.btn_Addition.Size = New System.Drawing.Size(75, 23)
        Me.btn_Addition.TabIndex = 0
        Me.btn_Addition.Text = "+"
        Me.btn_Addition.UseVisualStyleBackColor = True
        '
        'btn_Subtraction
        '
        Me.btn_Subtraction.Location = New System.Drawing.Point(93, 190)
        Me.btn_Subtraction.Name = "btn_Subtraction"
        Me.btn_Subtraction.Size = New System.Drawing.Size(75, 23)
        Me.btn_Subtraction.TabIndex = 1
        Me.btn_Subtraction.Text = "-"
        Me.btn_Subtraction.UseVisualStyleBackColor = True
        '
        'btn_Multiplication
        '
        Me.btn_Multiplication.Location = New System.Drawing.Point(174, 190)
        Me.btn_Multiplication.Name = "btn_Multiplication"
        Me.btn_Multiplication.Size = New System.Drawing.Size(75, 23)
        Me.btn_Multiplication.TabIndex = 2
        Me.btn_Multiplication.Text = "x"
        Me.btn_Multiplication.UseVisualStyleBackColor = True
        '
        'btn_Exponential
        '
        Me.btn_Exponential.Location = New System.Drawing.Point(255, 190)
        Me.btn_Exponential.Name = "btn_Exponential"
        Me.btn_Exponential.Size = New System.Drawing.Size(75, 23)
        Me.btn_Exponential.TabIndex = 3
        Me.btn_Exponential.Text = "^"
        Me.btn_Exponential.UseVisualStyleBackColor = True
        '
        'btn_Division
        '
        Me.btn_Division.Location = New System.Drawing.Point(12, 247)
        Me.btn_Division.Name = "btn_Division"
        Me.btn_Division.Size = New System.Drawing.Size(75, 23)
        Me.btn_Division.TabIndex = 4
        Me.btn_Division.Text = "/"
        Me.btn_Division.UseVisualStyleBackColor = True
        '
        'btn_IntDivision
        '
        Me.btn_IntDivision.Location = New System.Drawing.Point(93, 247)
        Me.btn_IntDivision.Name = "btn_IntDivision"
        Me.btn_IntDivision.Size = New System.Drawing.Size(75, 23)
        Me.btn_IntDivision.TabIndex = 5
        Me.btn_IntDivision.Text = "\"
        Me.btn_IntDivision.UseVisualStyleBackColor = True
        '
        'btn_Modulus
        '
        Me.btn_Modulus.Location = New System.Drawing.Point(174, 247)
        Me.btn_Modulus.Name = "btn_Modulus"
        Me.btn_Modulus.Size = New System.Drawing.Size(75, 23)
        Me.btn_Modulus.TabIndex = 6
        Me.btn_Modulus.Text = "Mod"
        Me.btn_Modulus.UseVisualStyleBackColor = True
        '
        'btn_Clear
        '
        Me.btn_Clear.Location = New System.Drawing.Point(255, 247)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(75, 23)
        Me.btn_Clear.TabIndex = 7
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Location = New System.Drawing.Point(336, 190)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(75, 80)
        Me.btn_Exit.TabIndex = 8
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(90, 67)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Number #1:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(90, 122)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Number #2:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(108, 317)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Answer:"
        '
        'lbl_Answer
        '
        Me.lbl_Answer.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lbl_Answer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Answer.Location = New System.Drawing.Point(174, 307)
        Me.lbl_Answer.Name = "lbl_Answer"
        Me.lbl_Answer.Size = New System.Drawing.Size(100, 23)
        Me.lbl_Answer.TabIndex = 12
        '
        'txt_NumOne
        '
        Me.txt_NumOne.Location = New System.Drawing.Point(174, 60)
        Me.txt_NumOne.Name = "txt_NumOne"
        Me.txt_NumOne.Size = New System.Drawing.Size(100, 20)
        Me.txt_NumOne.TabIndex = 13
        '
        'txt_NumTwo
        '
        Me.txt_NumTwo.Location = New System.Drawing.Point(174, 115)
        Me.txt_NumTwo.Name = "txt_NumTwo"
        Me.txt_NumTwo.Size = New System.Drawing.Size(100, 20)
        Me.txt_NumTwo.TabIndex = 14
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(423, 352)
        Me.Controls.Add(Me.txt_NumTwo)
        Me.Controls.Add(Me.txt_NumOne)
        Me.Controls.Add(Me.lbl_Answer)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.btn_Clear)
        Me.Controls.Add(Me.btn_Modulus)
        Me.Controls.Add(Me.btn_IntDivision)
        Me.Controls.Add(Me.btn_Division)
        Me.Controls.Add(Me.btn_Exponential)
        Me.Controls.Add(Me.btn_Multiplication)
        Me.Controls.Add(Me.btn_Subtraction)
        Me.Controls.Add(Me.btn_Addition)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_Addition As Button
    Friend WithEvents btn_Subtraction As Button
    Friend WithEvents btn_Multiplication As Button
    Friend WithEvents btn_Exponential As Button
    Friend WithEvents btn_Division As Button
    Friend WithEvents btn_IntDivision As Button
    Friend WithEvents btn_Modulus As Button
    Friend WithEvents btn_Clear As Button
    Friend WithEvents btn_Exit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lbl_Answer As Label
    Friend WithEvents txt_NumOne As TextBox
    Friend WithEvents txt_NumTwo As TextBox
End Class
