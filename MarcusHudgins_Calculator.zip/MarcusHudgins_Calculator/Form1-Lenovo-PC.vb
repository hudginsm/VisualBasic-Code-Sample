﻿Public Class Form1
    Private Sub btn_Addition_Click(sender As Object, e As EventArgs) Handles btn_Addition.Click
        Dim num1, num2, answer As Double
        num1 = txt_NumOne.Text
        num2 = txt_NumTwo.Text
        answer = num1 + num2
        lbl_Answer.Text = answer
    End Sub

    Private Sub btn_Subtraction_Click(sender As Object, e As EventArgs) Handles btn_Subtraction.Click
        Dim num1, num2, answer As Double
        num1 = txt_NumOne.Text
        num2 = txt_NumTwo.Text
        answer = num1 - num2
        lbl_Answer.Text = answer
    End Sub

    Private Sub btn_Multiplication_Click(sender As Object, e As EventArgs) Handles btn_Multiplication.Click
        Dim num1, num2, answer As Double
        num1 = txt_NumOne.Text
        num2 = txt_NumTwo.Text
        answer = num1 * num2
        lbl_Answer.Text = answer
    End Sub

    Private Sub btn_Exponential_Click(sender As Object, e As EventArgs) Handles btn_Exponential.Click
        Dim num1, num2, answer As Double
        num1 = txt_NumOne.Text
        num2 = txt_NumTwo.Text
        answer = num1 ^ num2
        lbl_Answer.Text = answer
    End Sub

    Private Sub btn_Division_Click(sender As Object, e As EventArgs) Handles btn_Division.Click
        Dim num1, num2, answer As Double
        num1 = txt_NumOne.Text
        num2 = txt_NumTwo.Text
        answer = num1 / num2
        lbl_Answer.Text = answer
    End Sub

    Private Sub btn_IntDivision_Click(sender As Object, e As EventArgs) Handles btn_IntDivision.Click
        Dim num1, num2, answer As Double
        num1 = txt_NumOne.Text
        num2 = txt_NumTwo.Text
        answer = num1 \ num2
        lbl_Answer.Text = answer
    End Sub

    Private Sub btn_Modulus_Click(sender As Object, e As EventArgs) Handles btn_Modulus.Click
        Dim num1, num2, answer As Double
        num1 = txt_NumOne.Text
        num2 = txt_NumTwo.Text
        answer = num1 Mod num2
        lbl_Answer.Text = answer
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        txt_NumOne.Clear()
        txt_NumTwo.Clear()
        lbl_Answer.Text = String.Empty
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub
End Class
