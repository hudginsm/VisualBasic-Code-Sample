﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lbl_Hours.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles lbl_GrossPayOutput.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btn_Close.Click
        Me.Close()
    End Sub
End Class
