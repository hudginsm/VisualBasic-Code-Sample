﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_CalcGrossPay = New System.Windows.Forms.Button()
        Me.lbl_Hours = New System.Windows.Forms.Label()
        Me.txt_HoursWorked = New System.Windows.Forms.TextBox()
        Me.txt_PayRate = New System.Windows.Forms.TextBox()
        Me.lbl_HourlyPay = New System.Windows.Forms.Label()
        Me.lbl_GrossPay = New System.Windows.Forms.Label()
        Me.lbl_GrossPayOutput = New System.Windows.Forms.Label()
        Me.btn_Close = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_CalcGrossPay
        '
        Me.btn_CalcGrossPay.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btn_CalcGrossPay.Location = New System.Drawing.Point(140, 305)
        Me.btn_CalcGrossPay.Name = "btn_CalcGrossPay"
        Me.btn_CalcGrossPay.Size = New System.Drawing.Size(84, 42)
        Me.btn_CalcGrossPay.TabIndex = 0
        Me.btn_CalcGrossPay.Text = "Calculate Gross Pay"
        Me.btn_CalcGrossPay.UseVisualStyleBackColor = True
        '
        'lbl_Hours
        '
        Me.lbl_Hours.AutoSize = True
        Me.lbl_Hours.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Hours.Location = New System.Drawing.Point(136, 79)
        Me.lbl_Hours.Name = "lbl_Hours"
        Me.lbl_Hours.Size = New System.Drawing.Size(130, 20)
        Me.lbl_Hours.TabIndex = 6
        Me.lbl_Hours.Text = "Number of Hours"
        '
        'txt_HoursWorked
        '
        Me.txt_HoursWorked.Location = New System.Drawing.Point(289, 81)
        Me.txt_HoursWorked.Name = "txt_HoursWorked"
        Me.txt_HoursWorked.Size = New System.Drawing.Size(189, 20)
        Me.txt_HoursWorked.TabIndex = 10
        '
        'txt_PayRate
        '
        Me.txt_PayRate.Location = New System.Drawing.Point(289, 137)
        Me.txt_PayRate.Name = "txt_PayRate"
        Me.txt_PayRate.Size = New System.Drawing.Size(189, 20)
        Me.txt_PayRate.TabIndex = 11
        '
        'lbl_HourlyPay
        '
        Me.lbl_HourlyPay.AutoSize = True
        Me.lbl_HourlyPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_HourlyPay.Location = New System.Drawing.Point(136, 137)
        Me.lbl_HourlyPay.Name = "lbl_HourlyPay"
        Me.lbl_HourlyPay.Size = New System.Drawing.Size(123, 20)
        Me.lbl_HourlyPay.TabIndex = 12
        Me.lbl_HourlyPay.Text = "Hourly Pay Rate"
        '
        'lbl_GrossPay
        '
        Me.lbl_GrossPay.AutoSize = True
        Me.lbl_GrossPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_GrossPay.Location = New System.Drawing.Point(136, 214)
        Me.lbl_GrossPay.Name = "lbl_GrossPay"
        Me.lbl_GrossPay.Size = New System.Drawing.Size(138, 20)
        Me.lbl_GrossPay.TabIndex = 13
        Me.lbl_GrossPay.Text = "Gross Pay Earned"
        '
        'lbl_GrossPayOutput
        '
        Me.lbl_GrossPayOutput.AutoSize = True
        Me.lbl_GrossPayOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_GrossPayOutput.Location = New System.Drawing.Point(285, 214)
        Me.lbl_GrossPayOutput.Name = "lbl_GrossPayOutput"
        Me.lbl_GrossPayOutput.Size = New System.Drawing.Size(49, 20)
        Me.lbl_GrossPayOutput.TabIndex = 14
        Me.lbl_GrossPayOutput.Text = "$0.00"
        '
        'btn_Close
        '
        Me.btn_Close.Location = New System.Drawing.Point(289, 315)
        Me.btn_Close.Name = "btn_Close"
        Me.btn_Close.Size = New System.Drawing.Size(75, 23)
        Me.btn_Close.TabIndex = 15
        Me.btn_Close.Text = "Close"
        Me.btn_Close.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(549, 434)
        Me.Controls.Add(Me.btn_Close)
        Me.Controls.Add(Me.lbl_GrossPayOutput)
        Me.Controls.Add(Me.lbl_GrossPay)
        Me.Controls.Add(Me.lbl_HourlyPay)
        Me.Controls.Add(Me.txt_PayRate)
        Me.Controls.Add(Me.txt_HoursWorked)
        Me.Controls.Add(Me.lbl_Hours)
        Me.Controls.Add(Me.btn_CalcGrossPay)
        Me.Name = "Form1"
        Me.Text = "Wage Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_CalcGrossPay As Button
    Friend WithEvents lbl_Hours As Label
    Friend WithEvents txt_HoursWorked As TextBox
    Friend WithEvents txt_PayRate As TextBox
    Friend WithEvents lbl_HourlyPay As Label
    Friend WithEvents lbl_GrossPay As Label
    Friend WithEvents lbl_GrossPayOutput As Label
    Friend WithEvents btn_Close As Button
End Class
