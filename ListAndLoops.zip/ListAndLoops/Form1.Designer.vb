﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstCandy = New System.Windows.Forms.ListBox()
        Me.lblChocolate = New System.Windows.Forms.Label()
        Me.lblNonChocolate = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstCandy
        '
        Me.lstCandy.FormattingEnabled = True
        Me.lstCandy.Items.AddRange(New Object() {"Skittels", "Starburst", "Sou Patch Kids"})
        Me.lstCandy.Location = New System.Drawing.Point(37, 152)
        Me.lstCandy.Name = "lstCandy"
        Me.lstCandy.Size = New System.Drawing.Size(120, 43)
        Me.lstCandy.TabIndex = 0
        '
        'lblChocolate
        '
        Me.lblChocolate.AutoSize = True
        Me.lblChocolate.Location = New System.Drawing.Point(34, 44)
        Me.lblChocolate.Name = "lblChocolate"
        Me.lblChocolate.Size = New System.Drawing.Size(55, 13)
        Me.lblChocolate.TabIndex = 1
        Me.lblChocolate.Text = "Chocolate"
        '
        'lblNonChocolate
        '
        Me.lblNonChocolate.AutoSize = True
        Me.lblNonChocolate.Location = New System.Drawing.Point(34, 136)
        Me.lblNonChocolate.Name = "lblNonChocolate"
        Me.lblNonChocolate.Size = New System.Drawing.Size(76, 13)
        Me.lblNonChocolate.TabIndex = 2
        Me.lblNonChocolate.Text = "non-Chocolate"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"Reeses", "Sneckers", "Muskateers", "Twix", "Zero Bar"})
        Me.ListBox1.Location = New System.Drawing.Point(37, 60)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(120, 43)
        Me.ListBox1.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Location = New System.Drawing.Point(172, 80)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 23)
        Me.Label1.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Location = New System.Drawing.Point(172, 172)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 5
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.lblNonChocolate)
        Me.Controls.Add(Me.lblChocolate)
        Me.Controls.Add(Me.lstCandy)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstCandy As ListBox
    Friend WithEvents lblChocolate As Label
    Friend WithEvents lblNonChocolate As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
