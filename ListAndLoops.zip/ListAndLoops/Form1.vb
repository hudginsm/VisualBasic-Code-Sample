﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Dim strName As String
        'Dim dblValue As Double
        'first argument is what you want to appear in the body of the input box. The second argument in the title.
        ' strName = InputBox("Enter your name", "Name")
        'When workin with other datatypes such as an int or double you must convert.
        'dblValue = CDbl()

        Dim numChoc, numFruity As Integer
        numChoc = ListBox1.Items.Count
        numFruity = lstCandy.Items.Count

        Label1.Text = numChoc
        Label2.Text = numFruity

        Dim intemNum1 As Integer = ListBox1.Items(0)

        lstCandy.Items.Add("Gummies")

        lstCandy.Items.Insert(2, "AirHeads")

        lstCandy.Items.Remove("Skittles")

        ListBox1.Items.RemoveAt(3)

        lstCandy.Items.Clear()



    End Sub
End Class
