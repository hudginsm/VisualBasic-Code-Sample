﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.pic_CardBack = New System.Windows.Forms.PictureBox()
        Me.pic_CardFront = New System.Windows.Forms.PictureBox()
        Me.btn_CardBack = New System.Windows.Forms.Button()
        Me.btn_CardFront = New System.Windows.Forms.Button()
        CType(Me.pic_CardBack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_CardFront, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pic_CardBack
        '
        Me.pic_CardBack.Image = CType(resources.GetObject("pic_CardBack.Image"), System.Drawing.Image)
        Me.pic_CardBack.Location = New System.Drawing.Point(42, 53)
        Me.pic_CardBack.Name = "pic_CardBack"
        Me.pic_CardBack.Size = New System.Drawing.Size(130, 200)
        Me.pic_CardBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_CardBack.TabIndex = 0
        Me.pic_CardBack.TabStop = False
        '
        'pic_CardFront
        '
        Me.pic_CardFront.Image = CType(resources.GetObject("pic_CardFront.Image"), System.Drawing.Image)
        Me.pic_CardFront.Location = New System.Drawing.Point(218, 53)
        Me.pic_CardFront.Name = "pic_CardFront"
        Me.pic_CardFront.Size = New System.Drawing.Size(114, 200)
        Me.pic_CardFront.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_CardFront.TabIndex = 1
        Me.pic_CardFront.TabStop = False
        Me.pic_CardFront.Visible = False
        '
        'btn_CardBack
        '
        Me.btn_CardBack.Location = New System.Drawing.Point(72, 301)
        Me.btn_CardBack.Name = "btn_CardBack"
        Me.btn_CardBack.Size = New System.Drawing.Size(75, 39)
        Me.btn_CardBack.TabIndex = 2
        Me.btn_CardBack.Text = "Show The Card Back"
        Me.btn_CardBack.UseVisualStyleBackColor = True
        '
        'btn_CardFront
        '
        Me.btn_CardFront.Location = New System.Drawing.Point(230, 301)
        Me.btn_CardFront.Name = "btn_CardFront"
        Me.btn_CardFront.Size = New System.Drawing.Size(75, 39)
        Me.btn_CardFront.TabIndex = 3
        Me.btn_CardFront.Text = "Show The Card Front"
        Me.btn_CardFront.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlText
        Me.ClientSize = New System.Drawing.Size(388, 366)
        Me.Controls.Add(Me.btn_CardFront)
        Me.Controls.Add(Me.btn_CardBack)
        Me.Controls.Add(Me.pic_CardFront)
        Me.Controls.Add(Me.pic_CardBack)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "Form1"
        Me.Text = "Card Flip"
        CType(Me.pic_CardBack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_CardFront, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pic_CardBack As PictureBox
    Friend WithEvents pic_CardFront As PictureBox
    Friend WithEvents btn_CardBack As Button
    Friend WithEvents btn_CardFront As Button
End Class
