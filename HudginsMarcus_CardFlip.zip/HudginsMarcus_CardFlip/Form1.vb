﻿Public Class Form1
    Private Sub btn_CardBack_Click(sender As Object, e As EventArgs) Handles btn_CardBack.Click
        pic_CardBack.Visible = True
        pic_CardFront.Visible = False
    End Sub

    Private Sub btn_CardFront_Click(sender As Object, e As EventArgs) Handles btn_CardFront.Click
        pic_CardBack.Visible = False
        pic_CardFront.Visible = True
    End Sub
End Class
