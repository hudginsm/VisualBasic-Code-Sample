﻿Public Class Form1
    Private Sub btn_One_Click(sender As Object, e As EventArgs) Handles btn_One.Click
        MessageBox.Show("un")
    End Sub

    Private Sub btn_Two_Click(sender As Object, e As EventArgs) Handles btn_Two.Click
        MessageBox.Show("deux")
    End Sub

    Private Sub btn_Three_Click(sender As Object, e As EventArgs) Handles btn_Three.Click
        MessageBox.Show("trois")
    End Sub

    Private Sub btn_Four_Click(sender As Object, e As EventArgs) Handles btn_Four.Click
        MessageBox.Show("quatre")
    End Sub

    Private Sub btn_Five_Click(sender As Object, e As EventArgs) Handles btn_Five.Click
        MessageBox.Show("cinq")
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub
End Class
