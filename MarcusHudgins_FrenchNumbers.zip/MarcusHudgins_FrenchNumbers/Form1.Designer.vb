﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_One = New System.Windows.Forms.Button()
        Me.btn_Two = New System.Windows.Forms.Button()
        Me.btn_Three = New System.Windows.Forms.Button()
        Me.btn_Four = New System.Windows.Forms.Button()
        Me.btn_Five = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.lbl_Title = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn_One
        '
        Me.btn_One.Location = New System.Drawing.Point(51, 124)
        Me.btn_One.Name = "btn_One"
        Me.btn_One.Size = New System.Drawing.Size(75, 23)
        Me.btn_One.TabIndex = 0
        Me.btn_One.Text = "1"
        Me.btn_One.UseVisualStyleBackColor = True
        '
        'btn_Two
        '
        Me.btn_Two.Location = New System.Drawing.Point(156, 125)
        Me.btn_Two.Name = "btn_Two"
        Me.btn_Two.Size = New System.Drawing.Size(75, 23)
        Me.btn_Two.TabIndex = 1
        Me.btn_Two.Text = "2"
        Me.btn_Two.UseVisualStyleBackColor = True
        '
        'btn_Three
        '
        Me.btn_Three.Location = New System.Drawing.Point(275, 124)
        Me.btn_Three.Name = "btn_Three"
        Me.btn_Three.Size = New System.Drawing.Size(75, 23)
        Me.btn_Three.TabIndex = 2
        Me.btn_Three.Text = "3"
        Me.btn_Three.UseVisualStyleBackColor = True
        '
        'btn_Four
        '
        Me.btn_Four.Location = New System.Drawing.Point(386, 126)
        Me.btn_Four.Name = "btn_Four"
        Me.btn_Four.Size = New System.Drawing.Size(75, 23)
        Me.btn_Four.TabIndex = 3
        Me.btn_Four.Text = "4"
        Me.btn_Four.UseVisualStyleBackColor = True
        '
        'btn_Five
        '
        Me.btn_Five.Location = New System.Drawing.Point(103, 197)
        Me.btn_Five.Name = "btn_Five"
        Me.btn_Five.Size = New System.Drawing.Size(75, 23)
        Me.btn_Five.TabIndex = 4
        Me.btn_Five.Text = "5"
        Me.btn_Five.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Location = New System.Drawing.Point(336, 197)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(75, 23)
        Me.btn_Exit.TabIndex = 5
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'lbl_Title
        '
        Me.lbl_Title.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Title.Location = New System.Drawing.Point(144, 22)
        Me.lbl_Title.Name = "lbl_Title"
        Me.lbl_Title.Size = New System.Drawing.Size(215, 79)
        Me.lbl_Title.TabIndex = 6
        Me.lbl_Title.Text = "Do you know the French words for the numbers 1 through 5? Click the buttons below" &
    " to see them."
        Me.lbl_Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(529, 278)
        Me.Controls.Add(Me.lbl_Title)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.btn_Five)
        Me.Controls.Add(Me.btn_Four)
        Me.Controls.Add(Me.btn_Three)
        Me.Controls.Add(Me.btn_Two)
        Me.Controls.Add(Me.btn_One)
        Me.Name = "Form1"
        Me.Text = "Frenchie"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btn_One As Button
    Friend WithEvents btn_Two As Button
    Friend WithEvents btn_Three As Button
    Friend WithEvents btn_Four As Button
    Friend WithEvents btn_Five As Button
    Friend WithEvents btn_Exit As Button
    Friend WithEvents lbl_Title As Label
End Class
