﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_Fifteen = New System.Windows.Forms.Button()
        Me.btn_Twenty = New System.Windows.Forms.Button()
        Me.btn_TwentyFive = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.lbl_Amount = New System.Windows.Forms.Label()
        Me.lbl_TipAmount = New System.Windows.Forms.Label()
        Me.lbl_Tip = New System.Windows.Forms.Label()
        Me.txt_Bill = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btn_Fifteen
        '
        Me.btn_Fifteen.Location = New System.Drawing.Point(8, 143)
        Me.btn_Fifteen.Name = "btn_Fifteen"
        Me.btn_Fifteen.Size = New System.Drawing.Size(75, 23)
        Me.btn_Fifteen.TabIndex = 0
        Me.btn_Fifteen.Text = "15%"
        Me.btn_Fifteen.UseVisualStyleBackColor = True
        '
        'btn_Twenty
        '
        Me.btn_Twenty.Location = New System.Drawing.Point(89, 143)
        Me.btn_Twenty.Name = "btn_Twenty"
        Me.btn_Twenty.Size = New System.Drawing.Size(75, 23)
        Me.btn_Twenty.TabIndex = 1
        Me.btn_Twenty.Text = "20%"
        Me.btn_Twenty.UseVisualStyleBackColor = True
        '
        'btn_TwentyFive
        '
        Me.btn_TwentyFive.Location = New System.Drawing.Point(170, 143)
        Me.btn_TwentyFive.Name = "btn_TwentyFive"
        Me.btn_TwentyFive.Size = New System.Drawing.Size(75, 23)
        Me.btn_TwentyFive.TabIndex = 2
        Me.btn_TwentyFive.Text = "25%"
        Me.btn_TwentyFive.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Location = New System.Drawing.Point(89, 226)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(75, 23)
        Me.btn_Exit.TabIndex = 3
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'lbl_Amount
        '
        Me.lbl_Amount.AutoSize = True
        Me.lbl_Amount.Location = New System.Drawing.Point(31, 73)
        Me.lbl_Amount.Name = "lbl_Amount"
        Me.lbl_Amount.Size = New System.Drawing.Size(71, 13)
        Me.lbl_Amount.TabIndex = 4
        Me.lbl_Amount.Text = "Amount of Bill"
        '
        'lbl_TipAmount
        '
        Me.lbl_TipAmount.AutoSize = True
        Me.lbl_TipAmount.Location = New System.Drawing.Point(25, 197)
        Me.lbl_TipAmount.Name = "lbl_TipAmount"
        Me.lbl_TipAmount.Size = New System.Drawing.Size(77, 13)
        Me.lbl_TipAmount.TabIndex = 5
        Me.lbl_TipAmount.Text = "Amount To Tip"
        '
        'lbl_Tip
        '
        Me.lbl_Tip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Tip.Location = New System.Drawing.Point(118, 184)
        Me.lbl_Tip.Name = "lbl_Tip"
        Me.lbl_Tip.Size = New System.Drawing.Size(65, 26)
        Me.lbl_Tip.TabIndex = 6
        '
        'txt_Bill
        '
        Me.txt_Bill.Location = New System.Drawing.Point(108, 70)
        Me.txt_Bill.Name = "txt_Bill"
        Me.txt_Bill.Size = New System.Drawing.Size(100, 20)
        Me.txt_Bill.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(256, 261)
        Me.Controls.Add(Me.txt_Bill)
        Me.Controls.Add(Me.lbl_Tip)
        Me.Controls.Add(Me.lbl_TipAmount)
        Me.Controls.Add(Me.lbl_Amount)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.btn_TwentyFive)
        Me.Controls.Add(Me.btn_Twenty)
        Me.Controls.Add(Me.btn_Fifteen)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_Fifteen As Button
    Friend WithEvents btn_Twenty As Button
    Friend WithEvents btn_TwentyFive As Button
    Friend WithEvents btn_Exit As Button
    Friend WithEvents lbl_Amount As Label
    Friend WithEvents lbl_TipAmount As Label
    Friend WithEvents lbl_Tip As Label
    Friend WithEvents txt_Bill As TextBox
End Class
