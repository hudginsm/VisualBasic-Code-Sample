﻿Public Class Form1
    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub

    Private Sub btn_Fifteen_Click(sender As Object, e As EventArgs) Handles btn_Fifteen.Click
        Dim billAmount As Double
        Dim tipAmount As Double
        billAmount = 0.0
        tipAmount = 0.0

        billAmount = CDbl(txt_Bill.Text)
        tipAmount = billAmount * 0.15
        lbl_Tip.Text = CStr(tipAmount)
    End Sub

    Private Sub btn_Twenty_Click(sender As Object, e As EventArgs) Handles btn_Twenty.Click
        Dim billAmount As Double
        Dim tipAmount As Double
        billAmount = 0.0
        tipAmount = 0.0

        billAmount = CDbl(txt_Bill.Text)
        tipAmount = billAmount * 0.2
        lbl_Tip.Text = CStr(tipAmount)
    End Sub

    Private Sub btn_TwentyFive_Click(sender As Object, e As EventArgs) Handles btn_TwentyFive.Click
        Dim billAmount As Double
        Dim tipAmount As Double
        billAmount = 0.0
        tipAmount = 0.0

        billAmount = CDbl(txt_Bill.Text)
        tipAmount = billAmount * 0.25
        lbl_Tip.Text = CStr(tipAmount)
    End Sub
End Class
