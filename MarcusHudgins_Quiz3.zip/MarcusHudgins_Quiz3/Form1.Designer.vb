﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_Claculate = New System.Windows.Forms.Button()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.btn_Close = New System.Windows.Forms.Button()
        Me.lbl_Title = New System.Windows.Forms.Label()
        Me.lbl_Output = New System.Windows.Forms.Label()
        Me.txt_SomeNum = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btn_Claculate
        '
        Me.btn_Claculate.Location = New System.Drawing.Point(12, 226)
        Me.btn_Claculate.Name = "btn_Claculate"
        Me.btn_Claculate.Size = New System.Drawing.Size(75, 23)
        Me.btn_Claculate.TabIndex = 0
        Me.btn_Claculate.Text = "Calculate"
        Me.btn_Claculate.UseVisualStyleBackColor = True
        '
        'btn_Clear
        '
        Me.btn_Clear.Location = New System.Drawing.Point(106, 226)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(75, 23)
        Me.btn_Clear.TabIndex = 1
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'btn_Close
        '
        Me.btn_Close.Location = New System.Drawing.Point(197, 226)
        Me.btn_Close.Name = "btn_Close"
        Me.btn_Close.Size = New System.Drawing.Size(75, 23)
        Me.btn_Close.TabIndex = 2
        Me.btn_Close.Text = "Close"
        Me.btn_Close.UseVisualStyleBackColor = True
        '
        'lbl_Title
        '
        Me.lbl_Title.AutoSize = True
        Me.lbl_Title.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Title.Location = New System.Drawing.Point(50, 49)
        Me.lbl_Title.Name = "lbl_Title"
        Me.lbl_Title.Size = New System.Drawing.Size(196, 20)
        Me.lbl_Title.TabIndex = 3
        Me.lbl_Title.Text = "Please Enter A Number"
        '
        'lbl_Output
        '
        Me.lbl_Output.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_Output.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Output.Location = New System.Drawing.Point(95, 151)
        Me.lbl_Output.Name = "lbl_Output"
        Me.lbl_Output.Size = New System.Drawing.Size(100, 23)
        Me.lbl_Output.TabIndex = 4
        '
        'txt_SomeNum
        '
        Me.txt_SomeNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SomeNum.Location = New System.Drawing.Point(95, 99)
        Me.txt_SomeNum.Name = "txt_SomeNum"
        Me.txt_SomeNum.Size = New System.Drawing.Size(100, 26)
        Me.txt_SomeNum.TabIndex = 5
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.txt_SomeNum)
        Me.Controls.Add(Me.lbl_Output)
        Me.Controls.Add(Me.lbl_Title)
        Me.Controls.Add(Me.btn_Close)
        Me.Controls.Add(Me.btn_Clear)
        Me.Controls.Add(Me.btn_Claculate)
        Me.Name = "Form1"
        Me.Text = "Multiply By Ten"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_Claculate As Button
    Friend WithEvents btn_Clear As Button
    Friend WithEvents btn_Close As Button
    Friend WithEvents lbl_Title As Label
    Friend WithEvents lbl_Output As Label
    Friend WithEvents txt_SomeNum As TextBox
End Class
