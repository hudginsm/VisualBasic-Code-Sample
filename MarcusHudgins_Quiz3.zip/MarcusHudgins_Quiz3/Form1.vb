﻿Public Class Form1
    Private Sub btn_Close_Click(sender As Object, e As EventArgs) Handles btn_Close.Click
        Me.Close()
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        txt_SomeNum.Clear()
        lbl_Output.Text = String.Empty
    End Sub

    Private Sub btn_Claculate_Click(sender As Object, e As EventArgs) Handles btn_Claculate.Click
        Dim InputNum As Double
        InputNum = txt_SomeNum.Text
        lbl_Output.Text = InputNum * 10
    End Sub
End Class
