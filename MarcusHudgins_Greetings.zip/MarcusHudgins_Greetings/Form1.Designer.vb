﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_Title = New System.Windows.Forms.Label()
        Me.txt_EnterText = New System.Windows.Forms.TextBox()
        Me.btn_Greeting = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.lbl_OutputText = New System.Windows.Forms.Label()
        Me.btn_Clear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbl_Title
        '
        Me.lbl_Title.AutoSize = True
        Me.lbl_Title.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Title.Location = New System.Drawing.Point(124, 68)
        Me.lbl_Title.Name = "lbl_Title"
        Me.lbl_Title.Size = New System.Drawing.Size(132, 20)
        Me.lbl_Title.TabIndex = 0
        Me.lbl_Title.Text = "Enter Your Name"
        '
        'txt_EnterText
        '
        Me.txt_EnterText.Location = New System.Drawing.Point(106, 110)
        Me.txt_EnterText.Name = "txt_EnterText"
        Me.txt_EnterText.Size = New System.Drawing.Size(157, 20)
        Me.txt_EnterText.TabIndex = 1
        '
        'btn_Greeting
        '
        Me.btn_Greeting.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Greeting.Location = New System.Drawing.Point(12, 189)
        Me.btn_Greeting.Name = "btn_Greeting"
        Me.btn_Greeting.Size = New System.Drawing.Size(87, 56)
        Me.btn_Greeting.TabIndex = 3
        Me.btn_Greeting.Text = "Show Greeting"
        Me.btn_Greeting.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Exit.Location = New System.Drawing.Point(256, 189)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(87, 56)
        Me.btn_Exit.TabIndex = 4
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'lbl_OutputText
        '
        Me.lbl_OutputText.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_OutputText.Location = New System.Drawing.Point(106, 152)
        Me.lbl_OutputText.Name = "lbl_OutputText"
        Me.lbl_OutputText.Size = New System.Drawing.Size(157, 23)
        Me.lbl_OutputText.TabIndex = 5
        '
        'btn_Clear
        '
        Me.btn_Clear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Clear.Location = New System.Drawing.Point(138, 189)
        Me.btn_Clear.Name = "btn_Clear"
        Me.btn_Clear.Size = New System.Drawing.Size(75, 56)
        Me.btn_Clear.TabIndex = 6
        Me.btn_Clear.Text = "Clear"
        Me.btn_Clear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(355, 269)
        Me.Controls.Add(Me.btn_Clear)
        Me.Controls.Add(Me.lbl_OutputText)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.btn_Greeting)
        Me.Controls.Add(Me.txt_EnterText)
        Me.Controls.Add(Me.lbl_Title)
        Me.Name = "Form1"
        Me.Text = "Greetings"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_Title As Label
    Friend WithEvents txt_EnterText As TextBox
    Friend WithEvents btn_Greeting As Button
    Friend WithEvents btn_Exit As Button
    Friend WithEvents lbl_OutputText As Label
    Friend WithEvents btn_Clear As Button
End Class
