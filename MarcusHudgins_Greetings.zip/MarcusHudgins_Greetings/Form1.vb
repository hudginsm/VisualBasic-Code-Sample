﻿Public Class Form1
    Private Sub btn_Greeting_Click(sender As Object, e As EventArgs) Handles btn_Greeting.Click
        'This line of code gathers info from the textbox
        lbl_OutputText.Text = "Hello " & txt_EnterText.Text & "!"
        MessageBox.Show(txt_EnterText.Text)
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        txt_EnterText.Clear()
        txt_EnterText.Text = String.Empty
        lbl_OutputText.Text = String.Empty
    End Sub
End Class
