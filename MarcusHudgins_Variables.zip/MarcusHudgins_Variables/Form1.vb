﻿Public Class Form1
    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub

    Private Sub btn_Clear_Click(sender As Object, e As EventArgs) Handles btn_Clear.Click
        txt_FristName.Clear()
        txt_LastName.Clear()
        lbl_Output.Text = String.Empty
    End Sub

    Private Sub btn_Name_Click(sender As Object, e As EventArgs) Handles btn_Name.Click
        'declare varables
        Dim firstName As String
        Dim lastName As String
        'initialize varables
        firstName = txt_FristName.Text
        lastName = txt_LastName.Text
        'displays first and last name 
        lbl_Output.Text = firstName & " " & lastName
    End Sub
End Class
