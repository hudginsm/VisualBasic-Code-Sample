﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.grbPlayerInputs = New System.Windows.Forms.GroupBox()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.txtPlayer2Guess = New System.Windows.Forms.TextBox()
        Me.txtPlayer1Guess = New System.Windows.Forms.TextBox()
        Me.btnReady = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grbCoinFlip = New System.Windows.Forms.GroupBox()
        Me.btnFlipCoin = New System.Windows.Forms.Button()
        Me.picHeads = New System.Windows.Forms.PictureBox()
        Me.picTails = New System.Windows.Forms.PictureBox()
        Me.grbPlayerOutputs = New System.Windows.Forms.GroupBox()
        Me.lblPlayer2Score = New System.Windows.Forms.Label()
        Me.lblPlayer1Score = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.grbPlayerInputs.SuspendLayout()
        Me.grbCoinFlip.SuspendLayout()
        CType(Me.picHeads, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grbPlayerOutputs.SuspendLayout()
        Me.SuspendLayout()
        '
        'grbPlayerInputs
        '
        Me.grbPlayerInputs.Controls.Add(Me.btnReset)
        Me.grbPlayerInputs.Controls.Add(Me.txtPlayer2Guess)
        Me.grbPlayerInputs.Controls.Add(Me.txtPlayer1Guess)
        Me.grbPlayerInputs.Controls.Add(Me.btnReady)
        Me.grbPlayerInputs.Controls.Add(Me.Label2)
        Me.grbPlayerInputs.Controls.Add(Me.Label1)
        Me.grbPlayerInputs.Location = New System.Drawing.Point(12, 12)
        Me.grbPlayerInputs.Name = "grbPlayerInputs"
        Me.grbPlayerInputs.Size = New System.Drawing.Size(386, 275)
        Me.grbPlayerInputs.TabIndex = 0
        Me.grbPlayerInputs.TabStop = False
        Me.grbPlayerInputs.Text = "Guesses"
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Location = New System.Drawing.Point(241, 192)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(95, 45)
        Me.btnReset.TabIndex = 5
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'txtPlayer2Guess
        '
        Me.txtPlayer2Guess.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPlayer2Guess.Location = New System.Drawing.Point(267, 115)
        Me.txtPlayer2Guess.Name = "txtPlayer2Guess"
        Me.txtPlayer2Guess.Size = New System.Drawing.Size(100, 26)
        Me.txtPlayer2Guess.TabIndex = 4
        '
        'txtPlayer1Guess
        '
        Me.txtPlayer1Guess.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPlayer1Guess.Location = New System.Drawing.Point(267, 78)
        Me.txtPlayer1Guess.Name = "txtPlayer1Guess"
        Me.txtPlayer1Guess.Size = New System.Drawing.Size(100, 26)
        Me.txtPlayer1Guess.TabIndex = 3
        '
        'btnReady
        '
        Me.btnReady.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReady.Location = New System.Drawing.Point(40, 192)
        Me.btnReady.Name = "btnReady"
        Me.btnReady.Size = New System.Drawing.Size(95, 45)
        Me.btnReady.TabIndex = 2
        Me.btnReady.Text = "Ready"
        Me.btnReady.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Palatino Linotype", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(10, 106)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(251, 35)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Player Two's Guess"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Palatino Linotype", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(248, 35)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Player One's Guess"
        '
        'grbCoinFlip
        '
        Me.grbCoinFlip.Controls.Add(Me.btnFlipCoin)
        Me.grbCoinFlip.Controls.Add(Me.picHeads)
        Me.grbCoinFlip.Controls.Add(Me.picTails)
        Me.grbCoinFlip.Location = New System.Drawing.Point(416, 12)
        Me.grbCoinFlip.Name = "grbCoinFlip"
        Me.grbCoinFlip.Size = New System.Drawing.Size(544, 530)
        Me.grbCoinFlip.TabIndex = 1
        Me.grbCoinFlip.TabStop = False
        Me.grbCoinFlip.Text = "CoinFlip"
        Me.grbCoinFlip.Visible = False
        '
        'btnFlipCoin
        '
        Me.btnFlipCoin.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFlipCoin.Location = New System.Drawing.Point(194, 401)
        Me.btnFlipCoin.Name = "btnFlipCoin"
        Me.btnFlipCoin.Size = New System.Drawing.Size(135, 81)
        Me.btnFlipCoin.TabIndex = 2
        Me.btnFlipCoin.Text = "Flip Coin"
        Me.btnFlipCoin.UseVisualStyleBackColor = True
        '
        'picHeads
        '
        Me.picHeads.Image = CType(resources.GetObject("picHeads.Image"), System.Drawing.Image)
        Me.picHeads.Location = New System.Drawing.Point(118, 53)
        Me.picHeads.Name = "picHeads"
        Me.picHeads.Size = New System.Drawing.Size(299, 305)
        Me.picHeads.TabIndex = 1
        Me.picHeads.TabStop = False
        '
        'picTails
        '
        Me.picTails.Image = CType(resources.GetObject("picTails.Image"), System.Drawing.Image)
        Me.picTails.Location = New System.Drawing.Point(118, 53)
        Me.picTails.Name = "picTails"
        Me.picTails.Size = New System.Drawing.Size(299, 305)
        Me.picTails.TabIndex = 0
        Me.picTails.TabStop = False
        Me.picTails.Visible = False
        '
        'grbPlayerOutputs
        '
        Me.grbPlayerOutputs.Controls.Add(Me.lblPlayer2Score)
        Me.grbPlayerOutputs.Controls.Add(Me.lblPlayer1Score)
        Me.grbPlayerOutputs.Controls.Add(Me.Label4)
        Me.grbPlayerOutputs.Controls.Add(Me.Label3)
        Me.grbPlayerOutputs.Location = New System.Drawing.Point(12, 306)
        Me.grbPlayerOutputs.Name = "grbPlayerOutputs"
        Me.grbPlayerOutputs.Size = New System.Drawing.Size(386, 236)
        Me.grbPlayerOutputs.TabIndex = 6
        Me.grbPlayerOutputs.TabStop = False
        Me.grbPlayerOutputs.Text = "Scores"
        Me.grbPlayerOutputs.Visible = False
        '
        'lblPlayer2Score
        '
        Me.lblPlayer2Score.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblPlayer2Score.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPlayer2Score.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlayer2Score.Location = New System.Drawing.Point(267, 42)
        Me.lblPlayer2Score.Name = "lblPlayer2Score"
        Me.lblPlayer2Score.Size = New System.Drawing.Size(100, 33)
        Me.lblPlayer2Score.TabIndex = 3
        '
        'lblPlayer1Score
        '
        Me.lblPlayer1Score.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblPlayer1Score.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPlayer1Score.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlayer1Score.Location = New System.Drawing.Point(267, 142)
        Me.lblPlayer1Score.Name = "lblPlayer1Score"
        Me.lblPlayer1Score.Size = New System.Drawing.Size(100, 33)
        Me.lblPlayer1Score.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Palatino Linotype", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(17, 140)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(244, 35)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Player Two's Score"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Palatino Linotype", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(20, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(241, 35)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Player One's Score"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(972, 554)
        Me.Controls.Add(Me.grbPlayerOutputs)
        Me.Controls.Add(Me.grbCoinFlip)
        Me.Controls.Add(Me.grbPlayerInputs)
        Me.Name = "Form1"
        Me.Text = "Heads vs Tails"
        Me.grbPlayerInputs.ResumeLayout(False)
        Me.grbPlayerInputs.PerformLayout()
        Me.grbCoinFlip.ResumeLayout(False)
        CType(Me.picHeads, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grbPlayerOutputs.ResumeLayout(False)
        Me.grbPlayerOutputs.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grbPlayerInputs As GroupBox
    Friend WithEvents txtPlayer2Guess As TextBox
    Friend WithEvents txtPlayer1Guess As TextBox
    Friend WithEvents btnReady As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents grbCoinFlip As GroupBox
    Friend WithEvents btnFlipCoin As Button
    Friend WithEvents picHeads As PictureBox
    Friend WithEvents picTails As PictureBox
    Friend WithEvents btnReset As Button
    Friend WithEvents grbPlayerOutputs As GroupBox
    Friend WithEvents lblPlayer2Score As Label
    Friend WithEvents lblPlayer1Score As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
End Class
