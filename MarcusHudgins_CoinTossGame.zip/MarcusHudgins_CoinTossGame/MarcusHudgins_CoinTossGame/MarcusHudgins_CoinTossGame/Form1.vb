﻿Imports System.Threading
Public Class Form1

    'My global variables
    Dim player1Guess, player2Guess As String
    Dim player1Choice, player2Choice As Integer
    Dim player1Score, player2Score As Integer

    Private Sub btnReady_Click(sender As Object, e As EventArgs) Handles btnReady.Click
        'Set variables as the players guesses
        player1Guess = txtPlayer1Guess.Text.ToLower()
        player2Guess = txtPlayer2Guess.Text.ToLower()

        'Setting the players choice based on their guess
        'Player One
        If player1Guess = "heads" Then
            player1Choice = 0
        ElseIf player1Guess = "tails" Then
            player1Choice = 1
        End If
        'Player Two
        If player2Guess = "heads" Then
            player2Choice = 0
        ElseIf player2Guess = "tails" Then
            player2Choice = 1
        End If

        'Opening the other sections
        If (player1Guess = "heads" Or player1Guess = "tails") And (player2Guess = "heads" Or player2Guess = "tails") Then
            grbCoinFlip.Visible = True
            grbPlayerOutputs.Visible = True
        Else
            MessageBox.Show("Error: Both players need to enter a guess.")
        End If
    End Sub

    Private Sub btnFlipCoin_Click(sender As Object, e As EventArgs) Handles btnFlipCoin.Click
        Dim Count, CoinFace As Integer
        Dim Rand As New Random
        player1Score = 0
        player2Score = 1

        For Count = 1 To 10
            'Determing the flip of the coin
            CoinFace = Rand.Next(2)
            If CoinFace = 0 Then
                picHeads.Visible = True
                picTails.Visible = False
            ElseIf CoinFace = 1 Then
                picTails.Visible = True
                picHeads.Visible = False
            End If
            'Adding up Player One's Score
            If player1Choice = CoinFace Then
                player1Score = player1Score + 1
                lblPlayer1Score.Text = player1Score
            End If
            'Adding up Player Two's Score
            If player2Choice = CoinFace Then
                player2Score = player2Score + 1
                lblPlayer2Score.Text = player2Score
            End If
        Next

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        'Resets Everything
        txtPlayer1Guess.Clear()
        txtPlayer2Guess.Clear()
        lblPlayer1Score.Text = String.Empty
        lblPlayer2Score.Text = String.Empty
        picHeads.Visible = True
        picTails.Visible = False
        grbCoinFlip.Visible = False
        grbPlayerOutputs.Visible = False
    End Sub

End Class
