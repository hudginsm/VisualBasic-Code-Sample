﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.pic_Orion = New System.Windows.Forms.PictureBox()
        Me.btn_Show = New System.Windows.Forms.Button()
        Me.btn_Hide = New System.Windows.Forms.Button()
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.lbl_Betelgeuse = New System.Windows.Forms.Label()
        Me.lbl_Meissa = New System.Windows.Forms.Label()
        Me.lbl_Alnitak = New System.Windows.Forms.Label()
        Me.lbl_Alnilam = New System.Windows.Forms.Label()
        Me.lbl_Mintaka = New System.Windows.Forms.Label()
        Me.lbl_Saiph = New System.Windows.Forms.Label()
        Me.lbl_Rigel = New System.Windows.Forms.Label()
        CType(Me.pic_Orion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pic_Orion
        '
        Me.pic_Orion.BackColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.pic_Orion.Image = CType(resources.GetObject("pic_Orion.Image"), System.Drawing.Image)
        Me.pic_Orion.Location = New System.Drawing.Point(0, 0)
        Me.pic_Orion.Name = "pic_Orion"
        Me.pic_Orion.Size = New System.Drawing.Size(530, 431)
        Me.pic_Orion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pic_Orion.TabIndex = 0
        Me.pic_Orion.TabStop = False
        '
        'btn_Show
        '
        Me.btn_Show.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Show.Location = New System.Drawing.Point(35, 437)
        Me.btn_Show.Name = "btn_Show"
        Me.btn_Show.Size = New System.Drawing.Size(123, 45)
        Me.btn_Show.TabIndex = 1
        Me.btn_Show.Text = "Show Names"
        Me.btn_Show.UseVisualStyleBackColor = True
        '
        'btn_Hide
        '
        Me.btn_Hide.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Hide.Location = New System.Drawing.Point(202, 437)
        Me.btn_Hide.Name = "btn_Hide"
        Me.btn_Hide.Size = New System.Drawing.Size(123, 45)
        Me.btn_Hide.TabIndex = 2
        Me.btn_Hide.Text = "Hide Names"
        Me.btn_Hide.UseVisualStyleBackColor = True
        '
        'btn_Exit
        '
        Me.btn_Exit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Exit.Location = New System.Drawing.Point(368, 437)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(123, 45)
        Me.btn_Exit.TabIndex = 3
        Me.btn_Exit.Text = "Exit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'lbl_Betelgeuse
        '
        Me.lbl_Betelgeuse.AutoSize = True
        Me.lbl_Betelgeuse.Location = New System.Drawing.Point(80, 28)
        Me.lbl_Betelgeuse.Name = "lbl_Betelgeuse"
        Me.lbl_Betelgeuse.Size = New System.Drawing.Size(60, 13)
        Me.lbl_Betelgeuse.TabIndex = 4
        Me.lbl_Betelgeuse.Text = "Betelgeuse"
        Me.lbl_Betelgeuse.Visible = False
        '
        'lbl_Meissa
        '
        Me.lbl_Meissa.AutoSize = True
        Me.lbl_Meissa.Location = New System.Drawing.Point(347, 63)
        Me.lbl_Meissa.Name = "lbl_Meissa"
        Me.lbl_Meissa.Size = New System.Drawing.Size(40, 13)
        Me.lbl_Meissa.TabIndex = 5
        Me.lbl_Meissa.Text = "Meissa"
        Me.lbl_Meissa.Visible = False
        '
        'lbl_Alnitak
        '
        Me.lbl_Alnitak.AutoSize = True
        Me.lbl_Alnitak.Location = New System.Drawing.Point(149, 216)
        Me.lbl_Alnitak.Name = "lbl_Alnitak"
        Me.lbl_Alnitak.Size = New System.Drawing.Size(39, 13)
        Me.lbl_Alnitak.TabIndex = 6
        Me.lbl_Alnitak.Text = "Alnitak"
        Me.lbl_Alnitak.Visible = False
        '
        'lbl_Alnilam
        '
        Me.lbl_Alnilam.AutoSize = True
        Me.lbl_Alnilam.Location = New System.Drawing.Point(199, 191)
        Me.lbl_Alnilam.Name = "lbl_Alnilam"
        Me.lbl_Alnilam.Size = New System.Drawing.Size(40, 13)
        Me.lbl_Alnilam.TabIndex = 7
        Me.lbl_Alnilam.Text = "Alnilam"
        Me.lbl_Alnilam.Visible = False
        '
        'lbl_Mintaka
        '
        Me.lbl_Mintaka.AutoSize = True
        Me.lbl_Mintaka.Location = New System.Drawing.Point(294, 182)
        Me.lbl_Mintaka.Name = "lbl_Mintaka"
        Me.lbl_Mintaka.Size = New System.Drawing.Size(45, 13)
        Me.lbl_Mintaka.TabIndex = 8
        Me.lbl_Mintaka.Text = "Mintaka"
        Me.lbl_Mintaka.Visible = False
        '
        'lbl_Saiph
        '
        Me.lbl_Saiph.AutoSize = True
        Me.lbl_Saiph.Location = New System.Drawing.Point(115, 356)
        Me.lbl_Saiph.Name = "lbl_Saiph"
        Me.lbl_Saiph.Size = New System.Drawing.Size(34, 13)
        Me.lbl_Saiph.TabIndex = 9
        Me.lbl_Saiph.Text = "Saiph"
        Me.lbl_Saiph.Visible = False
        '
        'lbl_Rigel
        '
        Me.lbl_Rigel.AutoSize = True
        Me.lbl_Rigel.Location = New System.Drawing.Point(347, 324)
        Me.lbl_Rigel.Name = "lbl_Rigel"
        Me.lbl_Rigel.Size = New System.Drawing.Size(31, 13)
        Me.lbl_Rigel.TabIndex = 10
        Me.lbl_Rigel.Text = "Rigel"
        Me.lbl_Rigel.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(530, 494)
        Me.Controls.Add(Me.lbl_Rigel)
        Me.Controls.Add(Me.lbl_Saiph)
        Me.Controls.Add(Me.lbl_Mintaka)
        Me.Controls.Add(Me.lbl_Alnilam)
        Me.Controls.Add(Me.lbl_Alnitak)
        Me.Controls.Add(Me.lbl_Meissa)
        Me.Controls.Add(Me.lbl_Betelgeuse)
        Me.Controls.Add(Me.btn_Exit)
        Me.Controls.Add(Me.btn_Hide)
        Me.Controls.Add(Me.btn_Show)
        Me.Controls.Add(Me.pic_Orion)
        Me.Name = "Form1"
        Me.Text = "Orion Constellation"
        CType(Me.pic_Orion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pic_Orion As PictureBox
    Friend WithEvents btn_Show As Button
    Friend WithEvents btn_Hide As Button
    Friend WithEvents btn_Exit As Button
    Friend WithEvents lbl_Betelgeuse As Label
    Friend WithEvents lbl_Meissa As Label
    Friend WithEvents lbl_Alnitak As Label
    Friend WithEvents lbl_Alnilam As Label
    Friend WithEvents lbl_Mintaka As Label
    Friend WithEvents lbl_Saiph As Label
    Friend WithEvents lbl_Rigel As Label
End Class
