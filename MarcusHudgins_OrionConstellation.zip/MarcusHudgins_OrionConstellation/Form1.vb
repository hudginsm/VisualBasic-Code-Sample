﻿Public Class Form1
    Private Sub btn_Show_Click(sender As Object, e As EventArgs) Handles btn_Show.Click
        lbl_Alnilam.Visible = True
        lbl_Alnitak.Visible = True
        lbl_Betelgeuse.Visible = True
        lbl_Meissa.Visible = True
        lbl_Mintaka.Visible = True
        lbl_Rigel.Visible = True
        lbl_Saiph.Visible = True
    End Sub

    Private Sub btn_Hide_Click(sender As Object, e As EventArgs) Handles btn_Hide.Click
        lbl_Alnilam.Visible = False
        lbl_Alnitak.Visible = False
        lbl_Betelgeuse.Visible = False
        lbl_Meissa.Visible = False
        lbl_Mintaka.Visible = False
        lbl_Rigel.Visible = False
        lbl_Saiph.Visible = False
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Me.Close()
    End Sub
End Class
